# SORT-RADIX-MACH Test Datasets

This directory contains test datasets for the **Radix Sort** benchmark from MachSuite.

## ⚠️ Important: About "Size"

Due to the algorithm's design and the use of fixed-size arrays defined by macros (e.g., `SIZE 2048`), all test sets for `sort-radix-mach` have **exactly the same input size** (2048 int32_t elements).

The different "sizes" (mini, small, medium, large, extra-large) represent different input array **patterns** generated with varying random seeds for correctness validation, NOT different computational scales. This approach allows for testing the algorithm's behavior across diverse input distributions while maintaining a consistent execution environment.

## Dataset Overview

| Size        | Random Seed | Description                               | Sample Input (First 5 values) |
|-------------|-------------|-------------------------------------------|-------------------------------|
| mini        | 1           | Standard random distribution (original seed) | (see below) |
| small       | 42          | Alternative random distribution           | (see below) |
| medium      | 123         | Different random pattern                  | (see below) |
| large       | 456         | Another random distribution               | (see below) |
| extra-large | 789         | Fifth random distribution                 | (see below) |

### Array Size (All datasets)
- **Elements**: 2048
- **Type**: int32_t
- **Size**: ~8 KB per input.data, ~8 KB per check.data

## Algorithm Information

### Radix Sort
Radix Sort is a **non-comparison** sorting algorithm that sorts integers by processing individual digits or bits. This implementation uses a 2-bit radix, processing 2 bits at a time.

**Key Characteristics:**
- **Time Complexity**: O(d × n) where d = number of passes (16 for 32-bit integers with 2-bit radix)
- **Space Complexity**: O(n) for auxiliary arrays
- **Stability**: Stable sort (preserves relative order of equal elements)
- **Type**: Non-comparison sort (doesn't compare elements directly)

**Algorithm Steps:**
1. **Initialize**: Set up buckets for each radix digit value
2. **Histogram**: Count occurrences of each digit value
3. **Scan**: Compute prefix sums (cumulative counts)
4. **Update**: Redistribute elements based on current digit
5. **Repeat**: Process next 2 bits (16 passes total for 32-bit integers)

**This Implementation:**
- **Radix size**: 2 bits (4 possible values: 0, 1, 2, 3)
- **Passes**: 32 bits ÷ 2 = 16 passes
- **Blocks**: 512 blocks of 4 elements each
- **Bucket size**: 512 blocks × 4 radix values = 2048 buckets
- **Double buffering**: Alternates between two arrays to avoid copying

## Directory Structure

```
input_data/
├── mini/
│   ├── input/
│   │   └── input.data       # Unsorted array (seed=1)
│   └── output/
│       └── check.data       # Sorted array (golden output)
├── small/
│   ├── input/input.data     # seed=42
│   └── output/check.data
├── medium/
│   ├── input/input.data     # seed=123
│   └── output/check.data
├── large/
│   ├── input/input.data     # seed=456
│   └── output/check.data
└── extra-large/
    ├── input/input.data     # seed=789
    └── output/check.data
```

## Data Format

### Input Format (input.data)
```
%% Section 1
int32_t[2048]: unsorted array
```

Each `input.data` contains 2048 random int32_t values generated using a pseudo-random number generator (PRNG) with a specific seed.

### Output Format (check.data)
```
%% Section 1
int32_t[2048]: sorted array (non-decreasing order)
```

Each `check.data` contains the corresponding sorted array in non-decreasing order.

### Verification Method
The `check_data()` function in `local_support.c` verifies correctness by:
1. **Sortedness Check**: Ensures `a[i-1] ≤ a[i]` for all i
2. **Sum Preservation**: Ensures sum of elements matches reference (detects missing/extra elements)

## Usage

### Test Single Size

```bash
./EX1_optimized_codes/sort_gcc \
    input_data/mini/input/input.data \
    input_data/mini/output/check.data
```

Expected output: `Success.`

### Test All Sizes

```bash
for size in mini small medium large extra-large; do
    echo "Testing $size..."
    ./EX1_optimized_codes/sort_gcc \
        input_data/$size/input/input.data \
        input_data/$size/output/check.data
done
```

Expected output: `Success.` for all sizes.

### Compare Performance (Optional)

```bash
for size in mini small medium large extra-large; do
    echo -n "$size: "
    time ./EX1_optimized_codes/sort_gcc \
        input_data/$size/input/input.data \
        input_data/$size/output/check.data
done
```

**Note**: Since all datasets have the same size, execution times should be similar across all "sizes".

## Regeneration

To regenerate all datasets from scratch:

```bash
# 1. Ensure baseline is compiled
make clean && make baseline

# 2. Run generation script
bash generate_all_data.sh
```

The script will:
1. Generate `input.data` for each size with different random seeds
2. Use the baseline executable to produce `check.data` (golden output)
3. Verify all datasets pass correctness tests

## Why Different Random Patterns?

Unlike comparison-based sorting algorithms, radix sort's performance is independent of input order. However, different distributions still affect:

1. **Branch Prediction**: Different digit distributions affect conditional branches
2. **Cache Behavior**: Different access patterns may impact cache performance
3. **Correctness Testing**: Ensures the algorithm works correctly across diverse inputs
4. **Compiler Optimization Testing**: Different patterns may trigger different compiler optimizations

### Pattern Characteristics

| Size        | Seed | Expected Distribution | Sort Difficulty |
|-------------|------|-----------------------|-----------------|
| mini        | 1    | Pseudo-random         | Uniform         |
| small       | 42   | Different random      | Uniform         |
| medium      | 123  | Different random      | Uniform         |
| large       | 456  | Different random      | Uniform         |
| extra-large | 789  | Different random      | Uniform         |

**Note**: Radix sort's time complexity is O(d×n) regardless of input distribution, making it very predictable.

## Fixed Size Rationale

The benchmark uses a fixed size (`SIZE 2048`) because:

1. **Hardware Synthesis**: MachSuite is designed for FPGA high-level synthesis (HLS), which requires compile-time known array sizes
2. **Fair Comparison**: Consistent size enables fair performance comparison across optimizations
3. **Memory Layout**: Fixed size allows static memory allocation, avoiding dynamic allocation overhead
4. **Algorithm Standard**: The implementation follows a standard radix sort pattern with fixed-size buffers

## Radix Sort Implementation Details

### 2-Bit Radix Approach

This implementation processes 2 bits at a time, dividing 32-bit integers into 16 groups:

```
32-bit integer:  [bits 31-30][bits 29-28]...[bits 3-2][bits 1-0]
                      Pass 16     Pass 15  ...  Pass 2   Pass 1
```

**Each pass:**
1. Extract 2 bits at position `exp` (0, 2, 4, ..., 30)
2. Count occurrences of each 2-bit value (0, 1, 2, 3)
3. Compute prefix sums to determine target positions
4. Redistribute elements to sorted positions

### Three-Stage Scan

The prefix sum computation uses a three-stage parallel scan:

1. **Local Scan**: Scan within each block (16 elements)
2. **Sum Scan**: Compute partial sums across blocks
3. **Last Step Scan**: Add block offsets to local results

This structure is optimized for parallel hardware execution.

### Double Buffering

The algorithm alternates between two arrays (A and B):
- **Odd passes**: Read from A, write to B
- **Even passes**: Read from B, write to A

This avoids the need to copy data back after each pass.

## Performance Characteristics

### Computational Complexity

For SIZE=2048:
- **Passes**: 16 (32 bits ÷ 2 bits per pass)
- **Operations per pass**: 
  - Histogram: ~2048 reads + ~2048 bucket increments
  - Scan: ~2048 prefix sum operations
  - Update: ~2048 reads + ~2048 writes
- **Total operations**: ~16 × (2048 × 4) ≈ 131,000 operations

### Memory Access Pattern

```
Pass 1:  Process bits [1:0]   - Distribute based on lowest 2 bits
Pass 2:  Process bits [3:2]   - Distribute based on next 2 bits
...
Pass 16: Process bits [31:30] - Distribute based on highest 2 bits (sign bit)
```

**Characteristics:**
- Sequential reads during histogram and update phases
- Random writes to buckets (cache-unfriendly)
- Regular pattern in scan phase (cache-friendly)

### Optimization Opportunities

1. **Larger Radix**: Use 4 or 8 bits per pass (fewer passes, larger buckets)
2. **Vectorization**: SIMD for histogram and update operations
3. **Cache Blocking**: Process data in cache-sized chunks
4. **Parallel Histogram**: Multiple threads compute histograms for different data ranges
5. **Hardware Pipelining**: Pipeline histogram, scan, and update stages in FPGA

## Comparison with Other Sorting Algorithms

| Algorithm      | Time Complexity | Space | Stability | Input Sensitivity | HLS-Friendly |
|----------------|-----------------|-------|-----------|-------------------|--------------|
| Radix Sort     | O(d×n)          | O(n)  | Yes       | No (uniform)      | ✓✓✓          |
| Merge Sort     | O(n log n)      | O(n)  | Yes       | No (uniform)      | ✓✓✓          |
| Quick Sort     | O(n log n)*     | O(1)  | No        | Yes (O(n²) worst) | ✗            |
| Heap Sort      | O(n log n)      | O(1)  | No        | No (uniform)      | ✓✓           |
| Counting Sort  | O(n+k)          | O(k)  | Yes       | No (uniform)      | ✓✓           |

*O(n²) worst case for quicksort

**Why Radix Sort for HLS:**
- Predictable control flow (no recursion, no data-dependent branches)
- Regular memory access patterns
- Highly parallel (independent histogram computations)
- No comparisons (simpler hardware)
- Stable performance across all inputs

## Educational Value

This benchmark demonstrates several important concepts:

### Algorithm Design
- **Non-comparison Sorting**: Exploiting structure of integers
- **Digit-by-digit Processing**: Stable sorting by significance
- **Counting and Redistribution**: Core technique for distribution sort

### Parallel Algorithms
- **Prefix Sum (Scan)**: Fundamental parallel primitive
- **Histogram Computation**: Parallel counting technique
- **Data Redistribution**: Parallel data movement patterns

### Hardware Optimization
- **Block-based Processing**: Exploiting parallelism at block level
- **Three-stage Scan**: Hierarchical parallel reduction
- **Double Buffering**: Avoiding data dependencies

### Performance Analysis
- **Input-independent Complexity**: Always O(d×n)
- **Cache Effects**: Random bucket writes vs sequential scans
- **Trade-offs**: Radix size vs number of passes

## Historical Context

Radix sort dates back to the 1880s, when Herman Hollerith used it for tabulating the U.S. Census using punched cards. Modern computer implementations:

- **1954**: First computer implementation on IBM 701
- **1960s**: Widely used for fixed-length records on tape
- **1980s**: Adapted for modern memory hierarchies
- **1990s-2000s**: GPU implementations for massive parallelism
- **2010s**: FPGA implementations for hardware acceleration

**This Implementation**: Based on the SHOC benchmark suite (Scalable Heterogeneous Computing), optimized for FPGA synthesis.

## Radix Sort Variants

### LSD vs MSD
- **LSD (Least Significant Digit)**: This implementation - processes from low to high bits
- **MSD (Most Significant Digit)**: Processes from high to low bits, can short-circuit

### In-place vs Out-of-place
- **This implementation**: Out-of-place (uses auxiliary array)
- **In-place variants**: Exist but more complex and less cache-friendly

### Radix Size Trade-offs
- **2-bit radix** (this impl): 16 passes, 4 buckets
- **4-bit radix**: 8 passes, 16 buckets
- **8-bit radix**: 4 passes, 256 buckets

**Trade-off**: Larger radix → fewer passes but more memory and worse cache behavior.

## Files in This Directory

- `README.md` (this file): Complete documentation
- `generate_all_data.sh`: Script to regenerate all datasets
- `mini/`, `small/`, `medium/`, `large/`, `extra-large/`: Dataset directories

## References

1. **SHOC Benchmark**: Danalis, A., et al. (2010). "The scalable heterogeneous computing (SHOC) benchmark suite"
2. **MachSuite**: Reagen, B., et al. (2014). "MachSuite: Benchmarks for accelerator design and customized architectures"
3. **Radix Sort History**: Knuth, D.E. "The Art of Computer Programming, Vol. 3: Sorting and Searching"
4. **Parallel Scan**: Blelloch, G.E. (1990). "Prefix sums and their applications"

## Notes

- All random values are generated using the MachSuite PRNG (`prng_rand`)
- Values are masked with `TYPE_MAX` to ensure positive int32_t values
- The `check_data()` function uses both sortedness and sum checks for robustness
- Execution time should be nearly identical across all "sizes" since array size is constant
- This is one of the few sorting benchmarks that doesn't benefit from pre-sorted input

---

**Generated**: November 2024  
**Benchmark**: MachSuite sort-radix-mach  
**Algorithm**: Radix Sort (2-bit LSD)  
**Array Size**: 2048 int32_t (FIXED)

