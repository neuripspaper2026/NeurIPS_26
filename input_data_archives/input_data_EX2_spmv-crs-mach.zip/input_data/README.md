# SPMV-CRS-MACH Test Datasets

This directory contains test datasets for the **Sparse Matrix-Vector Multiplication (SpMV)** benchmark from MachSuite, using the **Compressed Row Storage (CRS)** format.

## ⚠️ Important: About "Size"

Due to the benchmark's design using a fixed sparse matrix (IEEE 494 bus interconnect, 494×494 with 1666 nonzeros), all test sets for `spmv-crs-mach` have **exactly the same matrix structure**.

The different "sizes" (mini, small, medium, large, extra-large) represent different **input vectors** generated with varying random seeds for correctness validation, NOT different computational scales or matrix sizes. This approach allows for testing the algorithm's behavior across diverse input data while maintaining a consistent sparse matrix structure.

## Dataset Overview

| Size        | Random Seed | Description                      | Input Vector Pattern |
|-------------|-------------|----------------------------------|----------------------|
| mini        | 1           | Standard input vector (original)| Random (seed=1)      |
| small       | 42          | Alternative input vector        | Random (seed=42)     |
| medium      | 123         | Different input pattern         | Random (seed=123)    |
| large       | 456         | Another input vector            | Random (seed=456)    |
| extra-large | 789         | Fifth input vector              | Random (seed=789)    |

### Fixed Matrix Structure (All datasets)
- **Matrix**: IEEE 494 bus interconnect
- **Dimensions**: 494 × 494
- **Nonzeros (NNZ)**: 1666
- **Sparsity**: ~99.3% (only 0.68% nonzero)
- **Format**: CRS (Compressed Row Storage)
- **Type**: Symmetric, real-valued

### Variable Input (Per dataset)
- **Input Vector**: 494 double values (randomly generated per seed)
- **Output Vector**: 494 double values (result of y = A × x)

## Algorithm Information

### Sparse Matrix-Vector Multiplication (SpMV)
SpMV is a fundamental operation in scientific computing, computing `y = A × x` where A is a sparse matrix and x, y are dense vectors.

**Key Characteristics:**
- **Time Complexity**: O(NNZ) where NNZ is the number of nonzeros
- **Space Complexity**: O(NNZ + N) for CRS storage
- **Memory-Bound**: Performance limited by memory bandwidth
- **Irregular Access**: Column indices create irregular access patterns

**Algorithm Steps:**
1. For each row i (0 to N-1):
   - Initialize sum = 0
   - Get row start/end from rowDelimiters[i] and rowDelimiters[i+1]
   - For each nonzero j in row i:
     - Read value val[j] and column cols[j]
     - Multiply val[j] * vec[cols[j]]
     - Accumulate to sum
   - Store sum in out[i]

### CRS (Compressed Row Storage) Format

CRS stores only nonzero elements and their positions using three arrays:

**Data Structures:**
```c
double   val[NNZ];           // Nonzero values (1666 elements)
int32_t  cols[NNZ];          // Column indices (1666 elements)
int32_t  rowDelimiters[N+1]; // Row start positions (495 elements)
```

**Example:**
```
Dense Matrix (4×4):
  [1.0  0   2.0  0  ]
  [0    3.0 0    0  ]
  [4.0  0   5.0  6.0]
  [0    0   0    7.0]

CRS Representation:
  val:          [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0]
  cols:         [0,   2,   1,   0,   2,   3,   3]
  rowDelimiters:[0,   2,   3,   6,   7]
                 ↑    ↑    ↑    ↑    ↑
               row0 row1 row2 row3 end
```

**Advantages:**
- **Memory Efficient**: Only stores nonzeros (~0.68% of matrix)
- **Row-Wise Access**: Fast iteration over matrix rows
- **Natural for SpMV**: Directly supports row-vector multiplication

**Disadvantages:**
- **Irregular Access**: Column indices cause random access to input vector
- **Load Imbalance**: Different rows have different numbers of nonzeros
- **Poor Cache Locality**: Scattered reads from input vector

## Directory Structure

```
input_data/
├── mini/
│   ├── input/
│   │   └── input.data       # Matrix + input vector (seed=1)
│   └── output/
│       └── check.data       # Output vector (golden)
├── small/
│   ├── input/input.data     # seed=42
│   └── output/check.data
├── medium/
│   ├── input/input.data     # seed=123
│   └── output/check.data
├── large/
│   ├── input/input.data     # seed=456
│   └── output/check.data
└── extra-large/
    ├── input/input.data     # seed=789
    └── output/check.data
```

## Data Format

### Input Format (input.data)
```
%% Section 1: Nonzero values
double[1666]: val array

%% Section 2: Column indices
int32_t[1666]: cols array

%% Section 3: Row delimiters
int32_t[495]: rowDelimiters array (N+1 elements)

%% Section 4: Input vector
double[494]: vec array
```

### Output Format (check.data)
```
%% Section 1: Output vector
double[494]: out array (result of y = A × x)
```

### Verification Method
The `check_data()` function in `local_support.c` verifies correctness by comparing output vectors element-wise with tolerance `EPSILON = 1.0e-6`:
```c
for each element i:
    diff = data->out[i] - ref->out[i]
    error if |diff| > EPSILON
```

## Usage

### Test Single Size

```bash
./EX1_optimized_codes/spmv_gcc \
    input_data/mini/input/input.data \
    input_data/mini/output/check.data
```

Expected output: `Success.`

### Test All Sizes

```bash
for size in mini small medium large extra-large; do
    echo "Testing $size..."
    ./EX1_optimized_codes/spmv_gcc \
        input_data/$size/input/input.data \
        input_data/$size/output/check.data
done
```

Expected output: `Success.` for all sizes.

### Compare Performance (Optional)

```bash
for size in mini small medium large extra-large; do
    echo -n "$size: "
    time ./EX1_optimized_codes/spmv_gcc \
        input_data/$size/input/input.data \
        input_data/$size/output/check.data
done
```

**Note**: Since all datasets use the same matrix structure, execution times should be very similar across all "sizes".

## Regeneration

To regenerate all datasets from scratch:

```bash
# 1. Ensure baseline is compiled
make clean && make baseline

# 2. Run generation script
bash generate_all_data.sh
```

The script will:
1. Generate `input.data` for each size with different random input vectors
2. Use the baseline executable to produce `check.data` (golden output)
3. Verify all datasets pass correctness tests

## Why Different Input Vectors?

Although the SpMV algorithm's computational complexity is fixed at O(NNZ), different input vectors affect:

1. **Numerical Behavior**: Different values test floating-point accuracy
2. **Cache Behavior**: Different values may affect hardware prefetching
3. **Correctness Testing**: Ensures the algorithm works correctly across diverse inputs
4. **Output Validation**: Each input produces different expected outputs

### Input Vector Characteristics

All input vectors contain 494 random double values in range [0, 1), generated using PRNG with different seeds.

| Size        | Seed | Pattern Description |
|-------------|------|---------------------|
| mini        | 1    | Original baseline   |
| small       | 42   | Alternative random  |
| medium      | 123  | Different random    |
| large       | 456  | Another random      |
| extra-large | 789  | Fifth random        |

## Fixed Matrix Rationale

The benchmark uses a fixed matrix (IEEE 494 bus) because:

1. **Real-World Data**: Based on actual power system interconnect
2. **Standard Benchmark**: Widely used in sparse linear algebra research
3. **Reproducibility**: Consistent matrix enables fair performance comparison
4. **Hardware Synthesis**: MachSuite targets FPGA, which benefits from fixed-size data structures
5. **Algorithm Focus**: Tests SpMV implementation, not matrix generation

## IEEE 494 Bus Matrix

The 494 bus matrix represents an electrical power system:

**Properties:**
- **Domain**: Power system analysis
- **Size**: 494 nodes (buses)
- **Nonzeros**: 1666 connections
- **Symmetric**: Represents undirected power flow
- **Sparsity Pattern**: Realistic power grid topology
- **Source**: Matrix Market collection

**Sparsity Pattern:**
```
Density: 1666 / (494 × 494) = 0.68%
Average nonzeros per row: 1666 / 494 ≈ 3.37
```

This is typical for power system matrices, which have very few connections per node.

## Performance Characteristics

### Computational Complexity

For the IEEE 494 bus matrix:
- **Operations**: 1666 multiplies + 1666 adds = 3332 FLOPs
- **Memory Reads**: 
  - val array: 1666 doubles (13.3 KB)
  - cols array: 1666 int32_t (6.7 KB)
  - vec array: ~1666 random accesses to 494 doubles (3.9 KB)
- **Memory Writes**: 494 doubles (3.9 KB)

### Memory Access Pattern

```
For each row:
  Sequential:
    - Read rowDelimiters[i] and rowDelimiters[i+1]
    - Read val[j] for j in [start, end)
    - Read cols[j] for j in [start, end)
  
  Random (cache-unfriendly):
    - Read vec[cols[j]] - scattered reads based on column indices
  
  Sequential:
    - Write out[i]
```

**Performance Bottleneck**: Random reads from input vector (vec) based on column indices.

### Optimization Opportunities

1. **Vectorization**: SIMD for inner loop multiplications
2. **Prefetching**: Software prefetch for vec[cols[j]]
3. **Cache Blocking**: Process rows in blocks that fit in cache
4. **Parallel Rows**: Different threads process different rows
5. **Data Reordering**: Reorder columns to improve locality
6. **Register Blocking**: Accumulate multiple rows in registers

## Comparison with Other Sparse Formats

| Format     | Storage | Row Access | Col Access | Random Insert | Best For |
|------------|---------|------------|------------|---------------|----------|
| CRS        | 2*NNZ+N | O(1)       | O(log NNZ) | O(N)          | SpMV     |
| CCS        | 2*NNZ+N | O(log NNZ) | O(1)       | O(N)          | SpMV^T   |
| COO        | 3*NNZ   | O(NNZ)     | O(NNZ)     | O(1)          | Assembly |
| CSR (same as CRS) | 2*NNZ+N | O(1) | O(log NNZ) | O(N)      | SpMV     |

**CRS/CSR is optimal for**:
- Row-based matrix-vector multiplication
- Iterative solvers (most common sparse operation)
- Reading matrix once, using many times

## Educational Value

This benchmark demonstrates several important concepts:

### Sparse Linear Algebra
- **Storage Formats**: Efficient representation of sparse data
- **Index Indirection**: Indirect addressing through column indices
- **Matrix Properties**: Exploiting sparsity and structure

### Performance Optimization
- **Memory Bandwidth**: Typically the limiting factor for SpMV
- **Cache Effects**: Random access vs sequential access
- **Load Balancing**: Handling variable row lengths
- **Vectorization**: Challenges with irregular access patterns

### Parallel Computing
- **Row Parallelism**: Independent rows can run in parallel
- **Load Imbalance**: Different rows have different work
- **Data Locality**: Importance of cache-friendly access
- **Scalability**: Memory bandwidth limits speedup

### Scientific Computing
- **Iterative Solvers**: SpMV is the core of conjugate gradient, GMRES, etc.
- **Power Systems**: Real-world application domain
- **Numerical Accuracy**: Floating-point considerations

## Applications of SpMV

SpMV is fundamental to many scientific and engineering applications:

1. **Iterative Solvers**
   - Conjugate Gradient (CG)
   - GMRES (Generalized Minimal Residual)
   - Jacobi, Gauss-Seidel iterations

2. **Eigenvalue Problems**
   - Lanczos algorithm
   - Arnoldi iteration
   - Power method

3. **Graph Algorithms**
   - PageRank
   - Graph neural networks
   - Network analysis

4. **Scientific Simulation**
   - Finite element analysis
   - Computational fluid dynamics
   - Electromagnetics

5. **Machine Learning**
   - Sparse neural networks
   - Graph convolutional networks
   - Recommendation systems

## Historical Context

- **1950s**: Sparse storage formats developed for early computers
- **1970s**: CRS/CSR format standardized
- **1980s**: Iterative solvers become dominant for large systems
- **1990s**: Parallel SpMV on supercomputers
- **2000s**: GPU acceleration of SpMV
- **2010s**: FPGA implementations for specific matrices

**This Benchmark**: Based on real power system matrix from Matrix Market, standardized for FPGA high-level synthesis research.

## Files in This Directory

- `README.md` (this file): Complete documentation
- `generate_all_data.sh`: Script to regenerate all datasets
- `mini/`, `small/`, `medium/`, `large/`, `extra-large/`: Dataset directories

## References

1. **Matrix Market**: "494_bus matrix from Harwell-Boeing collection"
   - http://math.nist.gov/MatrixMarket/
2. **SpMV Survey**: "Sparse Matrix-Vector Multiplication on GPUs" (Bell & Garland, 2008)
3. **CRS Format**: "Sparse Matrix Storage Formats" (Saad, 2003)
4. **MachSuite**: Reagen, B., et al. (2014). "MachSuite: Benchmarks for accelerator design"

## Notes

- All random input vectors are generated using MachSuite PRNG (`prng_rand`)
- Values are normalized to range [0, 1)
- Matrix file `494_bus_full.mtx` is in Matrix Market format
- Floating-point comparison uses tolerance EPSILON = 1.0e-6
- Execution time should be nearly identical across all "sizes" (same matrix structure)

---

**Generated**: November 2024  
**Benchmark**: MachSuite spmv-crs-mach  
**Matrix**: IEEE 494 bus (494×494, 1666 NNZ, FIXED)  
**Algorithm**: SpMV with CRS format  
**Complexity**: O(NNZ) = O(1666)

