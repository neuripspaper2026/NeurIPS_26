# MD-KNN-Mach Dataset Documentation

This directory contains test datasets for the **MD-KNN-Mach** benchmark, which implements Molecular Dynamics (MD) simulation using a K-Nearest Neighbors (KNN) approach for efficient N-body force calculations.

---

## ⚠️ Important: About "Size"

Due to the algorithm's design and the use of fixed-size arrays defined by macros (e.g., `nAtoms 256`, `maxNeighbors 16`), all test sets for `md-knn-mach` have **exactly the same input size** (256 atoms with K=16 nearest neighbors each).

The different "sizes" (mini, small, medium, large, extra-large) represent different **random atom distributions** (spatial configurations) generated with varying random seeds for correctness validation, NOT different computational scales. This approach allows for testing the algorithm's behavior across diverse molecular configurations while maintaining a consistent execution environment.

---

## Dataset Structure

```
input_data/
├── mini/
│   ├── input/input.data     (~29KB: positions + neighbor lists)
│   └── output/check.data    (~15KB: force vectors)
├── small/
├── medium/
├── large/
├── extra-large/
└── README.md (this file)
```

---

## Dataset Details

| Size        | Random Seed | Description                               | Neighbor Pattern |
|-------------|-------------|-------------------------------------------|------------------|
| mini        | 1           | Standard random distribution (original)   | Varies by seed   |
| small       | 42          | Alternative random distribution           | Varies by seed   |
| medium      | 123         | Different random spatial pattern          | Varies by seed   |
| large       | 456         | Another random atom configuration         | Varies by seed   |
| extra-large | 789         | Fifth random distribution                 | Varies by seed   |

**Key Points:**
- All datasets: 256 atoms in a 20.0×20.0×20.0 domain
- K-Nearest Neighbors: K=16 (each atom interacts with its 16 closest neighbors)
- Lennard-Jones potential parameters: lj1=1.5, lj2=2.0
- Van der Waals threshold: 1.049² (prevents atom overlap)
- Different seeds produce different spatial distributions and neighbor lists

---

## Algorithm Overview

### MD-KNN (Molecular Dynamics with K-Nearest Neighbors)

**Purpose:**  
Calculate inter-atomic forces in a molecular dynamics simulation using the Lennard-Jones potential with K-Nearest Neighbors optimization for efficient neighbor searches.

**Key Features:**
- **K-Nearest Neighbors**: Each atom only computes forces from its K=16 closest neighbors
- **Adaptive Selection**: Neighbor list adapts to atom positions (not fixed grid)
- **Lennard-Jones Potential**: Models van der Waals forces (attractive/repulsive)
- **N-body Problem**: Computes pairwise forces for all 256 atoms

**Complexity:**
- Naive N-body: O(n²) = O(65,536) comparisons
- KNN-accelerated: O(n × K) = O(256 × 16) = O(4,096) comparisons
- **Speedup**: ~16× due to neighbor list pruning

**Algorithm Steps:**
1. **Position Generation**: Randomly place 256 atoms in [0, 20.0]³
2. **Distance Computation**: Calculate pairwise distances for all atom pairs
3. **KNN Selection**: Sort by distance and select K=16 nearest neighbors per atom
4. **Neighbor List**: Store indices of K nearest neighbors for each atom
5. **Force Calculation**: Compute Lennard-Jones forces only for neighbor pairs
6. **Accumulation**: Sum forces acting on each atom

---

## Data Format

### Input (`input.data`):

```
%% Section 1: X Positions (256 double values)
position_x[nAtoms]  # X coordinates of all atoms

%% Section 2: Y Positions (256 double values)
position_y[nAtoms]  # Y coordinates of all atoms

%% Section 3: Z Positions (256 double values)
position_z[nAtoms]  # Z coordinates of all atoms

%% Section 4: Neighbor List (4096 int32_t values)
NL[nAtoms*maxNeighbors]  # Indices of K=16 nearest neighbors for each atom
```

**Total size**: ~29 KB per input file

### Output (`check.data`):

```
%% Section 1: X Forces (256 double values)
force_x[nAtoms]  # X component of force on each atom

%% Section 2: Y Forces (256 double values)
force_y[nAtoms]  # Y component of force on each atom

%% Section 3: Z Forces (256 double values)
force_z[nAtoms]  # Z component of force on each atom
```

**Total size**: ~15 KB per output file

### Validation:
- Epsilon: 1.0e-6 (floating-point tolerance)
- Checks: All force components (x, y, z) for all atoms
- Method: Absolute difference comparison

---

## Physical Background

### Lennard-Jones Potential

The Lennard-Jones (LJ) potential models van der Waals interactions:

```
U(r) = 4ε[(σ/r)¹² - (σ/r)⁶]
```

Where:
- **r**: Distance between atoms
- **ε**: Depth of potential well (energy scale)
- **σ**: Finite distance at which potential is zero (length scale)

**Force Calculation:**

```
F(r) = -dU/dr = 24ε/r × [2(σ/r)¹² - (σ/r)⁶]
```

**Parameters in this benchmark:**
- `lj1 = 4ε·σ¹² = 1.5` (repulsive term)
- `lj2 = 4ε·σ⁶ = 2.0` (attractive term)
- Van der Waals radius: σ ≈ 1.049

**Physical Interpretation:**
- **r < σ**: Strong repulsion (atoms too close)
- **r ≈ σ**: Equilibrium (minimum energy)
- **r > σ**: Weak attraction (van der Waals)
- **r >> σ**: Negligible interaction (cutoff)

---

## K-Nearest Neighbors Optimization

### Why Use KNN?

**Problem**: Naive N-body force calculation requires checking all pairs:
- Time complexity: O(n²)
- For 256 atoms: 32,640 pairwise comparisons

**Solution**: K-Nearest Neighbors approach:
1. **Preprocessing**: For each atom, find its K=16 nearest neighbors
2. **Force Computation**: Only calculate forces for neighbor pairs
3. **Assumption**: Atoms beyond K nearest have negligible force contribution

**Benefits:**
- Reduces computations from O(n²) to O(n × K)
- Typical: 256 × 16 = 4,096 force evaluations vs. 32,640
- **Effective Speedup**: ~16× (factor of n/K = 256/16)

**Trade-offs:**
- **Preprocessing Cost**: O(n² log n) to compute all distances and sort
- **Memory Overhead**: Store K neighbors per atom (256 × 16 = 4,096 integers)
- **Accuracy**: Assumes far atoms have negligible forces (valid for LJ potential)
- **Static**: Neighbor list computed once (doesn't update during simulation)

---

## Comparison: MD-KNN vs MD-Grid

Both benchmarks solve the same N-body problem but use different optimization strategies:

| Feature | MD-Grid | MD-KNN |
|---------|---------|--------|
| **Partitioning** | Fixed 4×4×4 spatial grid | Adaptive K=16 nearest neighbors |
| **Search Strategy** | Check 27 neighboring cells | Check K=16 nearest atoms |
| **Neighbor Count** | Variable (0-10 per cell) | Fixed (K=16 per atom) |
| **Complexity** | O(n × 27 × density) ≈ O(n × 100) | O(n × K) = O(n × 16) |
| **Memory Access** | Regular grid pattern | Irregular neighbor indices |
| **Best For** | Uniform atom distributions | Sparse/clustered distributions |
| **Preprocessing** | Binning: O(n) | KNN: O(n² log n) |
| **Adaptivity** | Fixed spatial structure | Adapts to atom positions |

**Key Insight:**
- **MD-Grid**: Lower preprocessing cost, good for uniform densities
- **MD-KNN**: More adaptive, better for non-uniform distributions

---

## Dataset Characteristics

### Spatial Distribution

Each dataset has a unique atom distribution due to different random seeds:

**Generation Process:**
1. Randomly generate 3D positions in [0, 20.0]³
2. Reject positions violating van der Waals threshold (prevents overlap)
3. Accept when 256 valid atoms are generated
4. Compute pairwise distances for all atom pairs
5. For each atom, sort neighbors by distance
6. Select K=16 nearest neighbors
7. Store neighbor indices in neighbor list

**Properties:**
- **Random Distribution**: Atoms uniformly distributed in space
- **Physical Validity**: All atoms respect minimum distance constraint
- **Neighbor Diversity**: K=16 captures local neighborhood structure
- **Cutoff Implicit**: Far atoms (beyond K) ignored

### Why Different Seeds Matter

Different random seeds produce:
- **Varied Clustering**: Different local densities around atoms
- **Neighbor Patterns**: Different sets of K nearest neighbors
- **Distance Distributions**: Varied distances to nearest neighbors
- **Force Magnitudes**: Different force patterns based on configurations

This diversity ensures the algorithm is tested across realistic molecular configurations.

---

## Usage

### Test Single Dataset:

```bash
./EX1_optimized_codes/md_gcc \
    input_data/mini/input/input.data \
    input_data/mini/output/check.data
```

**Expected output:**
```
Success.
```

### Test All Datasets:

```bash
for size in mini small medium large extra-large; do
    echo "Testing $size..."
    ./EX1_optimized_codes/md_gcc \
        input_data/$size/input/input.data \
        input_data/$size/output/check.data
done
```

### Regenerate All Data:

```bash
# From md-knn-mach directory
bash generate_all_data.sh
```

---

## Performance Considerations

### Computational Characteristics

**Dominant Operations:**
- Distance calculations: `sqrt((x1-x2)² + (y1-y2)² + (z1-z2)²)` (preprocessing)
- Force evaluation: Lennard-Jones potential (runtime)
- Neighbor lookup: Access via precomputed indices (runtime)

**Memory Access Pattern:**
- **Preprocessing**: O(n²) random access (all pairs)
- **Runtime**: Streaming positions + irregular neighbor access
- **Cache Behavior**: Poor locality due to neighbor indices

**Optimization Opportunities:**
- Vectorize distance computations (SIMD)
- Loop unrolling in force calculations
- Prefetch neighbor positions
- Exploit force symmetry: F_ij = -F_ji (if both in each other's K-list)

### Expected Runtime (O3 optimization):
- Mini/Small/Medium/Large/Extra-large: ~1-5 ms (all same size)
- Variation: ±20% due to different spatial distributions

---

## Physical Significance

### Applications of MD with KNN

Molecular dynamics with K-Nearest Neighbors is used in:

1. **Astrophysics**
   - Galactic simulations
   - Star cluster dynamics
   - Dark matter halos

2. **Materials Science**
   - Amorphous materials
   - Liquid simulations
   - Glass transitions

3. **Biochemistry**
   - Protein dynamics (coarse-grained)
   - Membrane simulations
   - Solvation effects

### Limitations of This Benchmark

- **Fixed K**: Real simulations use cutoff radius, not fixed K
- **Static Neighbors**: Real MD updates neighbors dynamically
- **Small System**: 256 atoms (production runs use millions)
- **Single Step**: Real MD requires time integration over many steps
- **No Periodic Boundaries**: Real simulations often use periodic conditions

---

## References

### Molecular Dynamics Background

- **Lennard-Jones Potential**: J. E. Jones, Proc. Royal Soc. A (1924)
- **MD Method**: B. J. Alder & T. E. Wainwright, J. Chem. Phys. (1957)
- **Neighbor Lists**: Verlet neighbor lists (1967)

### K-Nearest Neighbors

- **KNN Algorithm**: T. Cover & P. Hart, IEEE Trans. Inf. Theory (1967)
- **Fast KNN**: J. Bentley, Comm. ACM (1975) - k-d trees
- **Applications**: Pattern recognition, clustering, simulations

### Related Benchmarks

- **md-grid-mach**: Grid-based spatial partitioning (same problem, different method)
- **nw-mach**: Needleman-Wunsch (different application, but also dynamic programming)

---

## Troubleshooting

### Common Issues

**Issue**: "Invalid input: line X of section Y"
- **Cause**: Corrupted input data file
- **Fix**: Regenerate using `bash generate_all_data.sh`

**Issue**: "Benchmark results are incorrect"
- **Cause**: check.data doesn't match computed forces
- **Fix**: Regenerate check.data using baseline program

**Issue**: All forces are zero
- **Cause**: Atoms too far apart (beyond K neighbors)
- **Fix**: Normal for some configurations; check if seed produces valid distribution

**Issue**: Segmentation fault during generation
- **Cause**: Stack overflow from large arrays in generate.c
- **Fix**: Use provided script which properly allocates memory

---

## Algorithm Details

### Neighbor List Construction

```c
// For each atom i:
for (i = 0; i < nAtoms; i++) {
    // Compute distances to all other atoms
    for (j = 0; j < nAtoms; j++) {
        if (i != j) {
            dist[j] = sqrt((x[i]-x[j])² + (y[i]-y[j])² + (z[i]-z[j])²);
        } else {
            dist[j] = infinity;  // Exclude self
        }
    }
    
    // Sort by distance and take K nearest
    sort(dist);
    NL[i*K : (i+1)*K] = indices_of_K_smallest(dist);
}
```

### Force Calculation

```c
// For each atom i:
for (i = 0; i < nAtoms; i++) {
    force[i] = (0, 0, 0);
    
    // Only interact with K nearest neighbors
    for (k = 0; k < K; k++) {
        j = NL[i*K + k];  // Get neighbor index
        
        // Compute distance
        r = sqrt((x[i]-x[j])² + (y[i]-y[j])² + (z[i]-z[j])²);
        
        // Lennard-Jones force
        F = 24*ε/r × [2(σ/r)¹² - (σ/r)⁶];
        
        // Accumulate force vector
        force[i] += F × (pos[i] - pos[j]) / r;
    }
}
```

---

## Dataset Metadata

| Property | Value |
|----------|-------|
| Benchmark Name | md-knn-mach |
| Algorithm | Molecular Dynamics (Lennard-Jones) |
| Optimization | K-Nearest Neighbors (K=16) |
| Input Size | Fixed (256 atoms) |
| Dataset Count | 5 |
| Total Data Size | ~220 KB (10 files) |
| Validation Method | Floating-point comparison (ε=1e-6) |
| Generation Time | ~2 seconds (all datasets) |
| Verification Time | ~5 ms per dataset |

---

## Summary

The **MD-KNN-Mach** dataset provides 5 test cases with different random atom distributions for validating molecular dynamics implementations. All datasets maintain the same size (256 atoms) but vary in spatial configuration, ensuring comprehensive testing of the K-Nearest Neighbors force calculation algorithm across diverse molecular scenarios.

**Key Takeaways:**
- ✅ Fixed scale: All datasets use 256 atoms with K=16 neighbors
- ✅ Different patterns: 5 random spatial distributions
- ✅ Physically valid: All atoms respect minimum distance constraints
- ✅ Algorithm test: KNN-based N-body force calculation
- ✅ Optimization target: Neighbor list pruning for reduced complexity

**Comparison to MD-Grid:**
- Both solve the same N-body problem
- MD-KNN uses adaptive neighbor selection (K=16 nearest)
- MD-Grid uses fixed spatial partitioning (4×4×4 cells)
- MD-KNN better for non-uniform distributions
- MD-Grid better for uniform distributions

For questions or issues, refer to the MachSuite documentation or regenerate data using the provided script.

