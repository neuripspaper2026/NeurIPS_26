# Dijkstra-mibench Input Data

## Overview

This directory contains adjacency matrix data files for testing the Dijkstra shortest path algorithm across different graph sizes.

## Directory Structure

```
input_data/
├── mini/
│   ├── input/
│   │   └── input.dat          (100×100, 45 KB)
│   └── output/                (benchmark results)
├── small/
│   ├── input/
│   │   └── input.dat          (200×200, 184 KB)
│   └── output/
├── medium/
│   ├── input/
│   │   └── input.dat          (500×500, 1.2 MB)
│   └── output/
├── large/
│   ├── input/
│   │   └── input.dat          (1000×1000, 4.9 MB)
│   └── output/
└── extra-large/
    ├── input/
    │   └── input.dat          (2000×2000, 20 MB)
    └── output/
```

## Dataset Specifications

### Mini (100 nodes)
- **Nodes**: 100
- **Sparsity**: 30% (≈3,000 edges)
- **Max Weight**: 100
- **File Size**: 45 KB
- **Runtime**: ~0.01s
- **Description**: Quick validation and debugging

### Small (400 nodes)
- **Nodes**: 400
- **Sparsity**: 20% (≈32,000 edges)
- **Max Weight**: 100
- **File Size**: 749 KB
- **Runtime**: ~0.05s
- **Description**: Small-scale testing

### Medium (1000 nodes)
- **Nodes**: 1000
- **Sparsity**: 12% (≈120,000 edges)
- **Max Weight**: 100
- **File Size**: 4.9 MB
- **Runtime**: ~0.36s
- **Description**: Medium-scale testing

### Large (2000 nodes)
- **Nodes**: 2000
- **Sparsity**: 8% (≈320,000 edges)
- **Max Weight**: 100
- **File Size**: 19.7 MB
- **Runtime**: ~1.56s
- **Description**: Large-scale testing

### Extra-Large (4000 nodes)
- **Nodes**: 4000
- **Sparsity**: 4% (≈640,000 edges)
- **Max Weight**: 100
- **File Size**: 80.3 MB
- **Runtime**: ~7.69s
- **Description**: Stress testing and performance evaluation

## File Format

Each `input.dat` file contains:
- Adjacency matrix for a directed weighted graph
- N×N integers where N is the number of nodes
- Format: Space-separated integers, 10 values per line
- Edge weights: 1-100 (random)
- No edge: 9999 (special value NONE)
- No self-loops: diagonal elements are 9999

### Example (3×3 matrix)

```
9999 5 10
15 9999 20
9999 8 9999
```

Interpretation:
- Node 0 → Node 1: weight 5
- Node 0 → Node 2: weight 10
- Node 1 → Node 0: weight 15
- Node 1 → Node 2: weight 20
- Node 2 → Node 1: weight 8
- All other connections: no edge (9999)

## Data Generation

All datasets were generated using `generate.py` with seed 42 for reproducibility:

```bash
for size in mini small medium large extra-large; do
    python3 generate.py synthetic --preset $size \
        --out-dir input_data/$size/input --seed 42
done
```

## Graph Properties

### Sparsity

Sparsity decreases with size to maintain reasonable runtimes:
- **Mini**: 30% - Dense enough for many paths
- **Small**: 20% - Moderate connectivity
- **Medium**: 12% - Sparse but connected
- **Large**: 8% - Very sparse
- **Extra-large**: 4% - Extremely sparse

### Connectivity

All generated graphs are:
- **Directed**: Edge A→B does not imply B→A
- **Weighted**: Random integer weights 1-100
- **Sparse**: Most node pairs have no direct edge
- **Connected**: High probability of paths between most nodes

## Usage

### Running Single Size

```bash
# Compile the benchmark
make

# Run on mini dataset
./EX1_optimized_codes/dijkstra_gcc input_data/mini/input/input.dat

# Run on large dataset
./EX1_optimized_codes/dijkstra_gcc input_data/large/input/input.dat
```

### Testing All Sizes

```bash
# Test all sizes and measure runtime
make test-sizes
```

Expected output:
```
=== Testing mini ===
Detected 100×100 adjacency matrix
Shortest path is 17 in cost. Path is:  0 58 20 78 50
...
real    0m0.009s

=== Testing small ===
Detected 200×200 adjacency matrix
...
real    0m0.011s

[etc.]
```

## Benchmark Behavior

The benchmark:
1. Reads the adjacency matrix from the input file
2. Detects the matrix size automatically
3. Finds shortest paths from 100 different starting nodes
4. Prints path cost and node sequence for each query
5. Uses Dijkstra's algorithm with priority queue

### Output Format

For each query:
```
Shortest path is <cost> in cost. Path is: <node0> <node1> ... <nodeN>
```

Example:
```
Shortest path is 17 in cost. Path is:  0 58 20 78 50
```
- From node 0 to node 50
- Total cost: 17
- Path: 0 → 58 → 20 → 78 → 50

## Performance Characteristics

| Size | Nodes | Edges | Memory | Time | Paths/sec |
|------|-------|-------|--------|------|-----------|
| mini | 100 | 3K | 40 KB | 0.01s | 10,000 |
| small | 400 | 32K | 640 KB | 0.05s | 2,000 |
| medium | 1000 | 120K | 4 MB | 0.36s | 278 |
| large | 2000 | 320K | 16 MB | 1.56s | 64 |
| extra-large | 4000 | 640K | 64 MB | 7.69s | 13 |

## Validation

### Correctness Checks

1. **Path exists**: Algorithm finds a path or reports none
2. **Optimal cost**: Path cost is minimal (Dijkstra guarantee)
3. **Valid edges**: All edges in path exist in the graph
4. **Consistent results**: Same input → same output

### Reproducing Results

To verify correctness:
```bash
# Run baseline
./EX1_optimized_codes/dijkstra_gcc input_data/mini/input/input.dat > output1.txt

# Run again
./EX1_optimized_codes/dijkstra_gcc input_data/mini/input/input.dat > output2.txt

# Compare
diff output1.txt output2.txt
```

Should produce no differences.

## Regenerating Data

To regenerate all datasets:

```bash
# Regenerate with same seed (identical results)
for size in mini small medium large extra-large; do
    python3 generate.py synthetic --preset $size \
        --out-dir input_data/$size/input --seed 42
done

# Generate with new random data
for size in mini small medium large extra-large; do
    python3 generate.py synthetic --preset $size \
        --out-dir input_data/$size/input
done
```

## Custom Datasets

Create custom graph configurations:

```bash
# 300-node graph, 40% sparse, max weight 50
python3 generate.py synthetic \
    --num-nodes 300 \
    --sparsity 0.4 \
    --max-weight 50 \
    --out-dir input_data/custom/input \
    --seed 12345

# Run on custom data
./EX1_optimized_codes/dijkstra_gcc input_data/custom/input/input.dat
```

## Memory Requirements

The parameterized binary allocates memory dynamically:
- **Matrix**: N² × 4 bytes (int)
- **Nodes**: N × 8 bytes (NODE struct)
- **Queue**: Variable, O(N) worst case

Total memory ≈ 4N² + 8N + queue overhead

| Nodes | Approx Memory |
|-------|---------------|
| 100 | < 1 MB |
| 500 | ~2 MB |
| 1000 | ~6 MB |
| 2000 | ~20 MB |
| 10000 | ~500 MB |

## Algorithm Complexity

- **Time**: O(N² log N) for N nodes (with binary heap priority queue)
- **Space**: O(N²) for adjacency matrix storage
- **Queries**: 100 shortest path computations per run

## Troubleshooting

**Problem**: "Detected X×X adjacency matrix" shows wrong size
- Solution: Regenerate data file, may be corrupted

**Problem**: Benchmark crashes with large datasets
- Solution: Check available memory, reduce dataset size

**Problem**: Results differ between runs
- Solution: Check for non-determinism in compiler optimizations or system state

**Problem**: Very long runtime
- Solution: Use smaller dataset or reduce node count

## See Also

- `../DATA_GENERATION_README.md` - Data generation guide
- `../generate.py` - Data generation script
- `../Makefile` - Build and test commands
- `../EX1_optimized_codes/dijkstra_parameterized.c` - Source code

