# BFS (Bulk) Test Datasets

This directory contains 5 test datasets for the BFS (Breadth-First Search) benchmark using the bulk synchronous parallel algorithm.

## ⚠️ Important: About "Size"

Due to the **fixed graph structure** defined by the BFS algorithm (SCALE=8, resulting in 256 nodes and 4096 edges), all test sets have **exactly the same input size**.

The different "sizes" represent different **random graph topologies** (generated with different random seeds) for correctness validation, NOT different computational scales. All graphs follow the R-MAT scale-free distribution but with different random structures.

---

## Dataset Description

**Important: All datasets have identical dimensions (256 nodes, 4096 edges).**

This is because the graph size is determined by the `SCALE` constant in `bfs.h`:
- `N_NODES = 2^SCALE = 256`
- `N_EDGES = N_NODES × EDGE_FACTOR = 4096`

| Size | Pattern | Random Seed | Description |
|------|---------|-------------|-------------|
| **mini** | Standard | 1 | Original R-MAT scale-free graph (matches root `input.data`) |
| **small** | Alternative | 42 | Different random scale-free topology |
| **medium** | Variant | 123 | Another random graph instance |
| **large** | Variant | 456 | Yet another random topology |
| **extra-large** | Variant | 789 | Fifth random topology variant |

All graphs use the same R-MAT parameters (A=57, B=19, C=19, D=5) to generate scale-free, small-world graphs, but with different random seeds to create topologically distinct graphs.

### Data Format

**Input (`input.data`):**
- Section 1: Starting node (1 × uint64_t)
- Section 2: Node structures (256 × 2 × uint64_t) - edge begin/end indices
- Section 3: Edge destinations (4096 × uint64_t)

**Output (`check.data`):**
- Section 1: Level counts (10 × uint64_t) - number of nodes at each BFS level

### Why Different Topologies?

Even with the same number of nodes and edges, different graph topologies can:
- Test different BFS traversal patterns (shallow vs. deep trees)
- Validate correctness across various graph structures
- Ensure the algorithm handles different edge distributions
- Provide diverse test cases for edge cases

---

## Usage

### Test Single Dataset

```bash
# Test mini dataset
./EX1_optimized_codes/bfs_gcc \
    input_data/mini/input/input.data \
    input_data/mini/output/check.data
```

Expected output: `Success.`

### Test All Datasets

```bash
# Test all sizes
for size in mini small medium large extra-large; do
    echo "Testing $size..."
    ./EX1_optimized_codes/bfs_gcc \
        input_data/$size/input/input.data \
        input_data/$size/output/check.data
done
```

Expected: All tests should print `Success.`

### Batch Testing

```bash
# Compile baseline first
make clean && make all

# Run tests
./EX1_optimized_codes/bfs_gcc input_data/mini/input/input.data input_data/mini/output/check.data
./EX1_optimized_codes/bfs_gcc input_data/small/input/input.data input_data/small/output/check.data
./EX1_optimized_codes/bfs_gcc input_data/medium/input/input.data input_data/medium/output/check.data
./EX1_optimized_codes/bfs_gcc input_data/large/input/input.data input_data/large/output/check.data
./EX1_optimized_codes/bfs_gcc input_data/extra-large/input/input.data input_data/extra-large/output/check.data
```

---

## Regeneration

To regenerate all datasets with fresh random topologies:

### Method 1: Using the provided script (Recommended)

```bash
./generate_all_data.sh
```

This script will:
1. Generate 5 different graph topologies with different random seeds
2. Compile the baseline program
3. Generate golden outputs (`check.data`) for each topology
4. Verify all datasets

### Method 2: Manual generation

```bash
# 1. Compile baseline
make clean && make all

# 2. Modify generate.c to use different seeds, then:
for size in mini small medium large extra-large; do
    # Edit generate.c to change the random seed
    # Recompile and run generator
    make generate
    mv input.data input_data/$size/input/input.data
    
    # Generate golden output
    ./EX1_optimized_codes/bfs_gcc \
        input_data/$size/input/input.data \
        input_data/$size/input/input.data
    cp EX5_correctness/output_gcc.data input_data/$size/output/check.data
done
```

---

## Verification

After regeneration, verify all datasets:

```bash
for size in mini small medium large extra-large; do
    echo -n "[$size] "
    ./EX1_optimized_codes/bfs_gcc \
        input_data/$size/input/input.data \
        input_data/$size/output/check.data && echo "PASS" || echo "FAIL"
done
```

All tests should show `Success.` and `PASS`.

---

## Technical Details

### Graph Generation Algorithm

Uses the R-MAT (Recursive MATrix) model to generate realistic scale-free graphs:
- **Parameters:** A=57%, B=19%, C=19%, D=5%
- **Method:** Recursive quadtree partitioning
- **Properties:** Power-law degree distribution, small-world characteristics
- **Undirected:** Each edge is bidirectional

### BFS Algorithm

- **Type:** Bulk synchronous parallel (level-synchronous)
- **Starting node:** Randomly selected node with degree ≥ 2
- **Max depth:** 10 levels
- **Output:** Count of nodes discovered at each BFS level

### File Sizes

Each dataset consists of:
- `input.data`: ~4,612 lines (~60 KB)
- `check.data`: 11 lines (~100 bytes)

---

## Notes

1. **Deterministic Generation:** Each seed produces a deterministic graph topology
2. **Graph Connectivity:** All generated graphs are ensured to be connected
3. **Starting Node:** Always has degree ≥ 2 to ensure meaningful traversal
4. **Output Validation:** Golden outputs are generated by the verified baseline program

---

## References

- Harish and Narayanan. "Accelerating large graph algorithms on the GPU using CUDA." HiPC, 2007.
- Hong, Oguntebi, Olukotun. "Efficient Parallel Graph Exploration on Multi-Core CPU and GPU." PACT, 2011.
- Chakrabarti et al. "R-MAT: A Recursive Model for Graph Mining." SDM, 2004.

