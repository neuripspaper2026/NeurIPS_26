# SORT-MERGE-MACH Test Datasets

This directory contains test datasets for the **Merge Sort** benchmark from MachSuite.

## ⚠️ Important: About "Size"

Due to the algorithm's design and the use of fixed-size arrays defined by macros (e.g., `SIZE 2048`), all test sets for `sort-merge-mach` have **exactly the same input size** (2048 int32_t elements).

The different "sizes" (mini, small, medium, large, extra-large) represent different input array **patterns** generated with varying random seeds for correctness validation, NOT different computational scales. This approach allows for testing the algorithm's behavior across diverse input distributions while maintaining a consistent execution environment.

## Dataset Overview

| Size        | Random Seed | Description                               | Sample Input (First 5 values) |
|-------------|-------------|-------------------------------------------|-------------------------------|
| mini        | 1           | Standard random distribution (original seed) | (see below) |
| small       | 42          | Alternative random distribution           | (see below) |
| medium      | 123         | Different random pattern                  | (see below) |
| large       | 456         | Another random distribution               | (see below) |
| extra-large | 789         | Fifth random distribution                 | (see below) |

### Array Size (All datasets)
- **Elements**: 2048
- **Type**: int32_t
- **Size**: ~8 KB per input.data, ~8 KB per check.data

## Algorithm Information

### Merge Sort
Merge Sort is a classic divide-and-conquer sorting algorithm that recursively divides the array into two halves, sorts them, and merges them back together.

**Key Characteristics:**
- **Time Complexity**: O(n log n) in all cases (best, average, worst)
- **Space Complexity**: O(n) for auxiliary array
- **Stability**: Stable sort (preserves relative order of equal elements)
- **Approach**: Bottom-up iterative implementation in this benchmark

**Algorithm Steps:**
1. **Divide**: Split array into subarrays of increasing sizes (1, 2, 4, 8, ...)
2. **Merge**: Combine adjacent subarrays in sorted order
3. **Repeat**: Continue until the entire array is sorted

**This Implementation:**
- Uses bottom-up (iterative) approach instead of top-down (recursive)
- Merge size doubles in each pass: 1→2→4→8→...→2048
- Total passes: log₂(2048) = 11 passes
- Each pass: ~2048 comparisons and moves
- Total operations: ~2048 × 11 = ~22,500 operations

## Directory Structure

```
input_data/
├── mini/
│   ├── input/
│   │   └── input.data       # Unsorted array (seed=1)
│   └── output/
│       └── check.data       # Sorted array (golden output)
├── small/
│   ├── input/input.data     # seed=42
│   └── output/check.data
├── medium/
│   ├── input/input.data     # seed=123
│   └── output/check.data
├── large/
│   ├── input/input.data     # seed=456
│   └── output/check.data
└── extra-large/
    ├── input/input.data     # seed=789
    └── output/check.data
```

## Data Format

### Input Format (input.data)
```
%% Section 1
int32_t[2048]: unsorted array
```

Each `input.data` contains 2048 random int32_t values generated using a pseudo-random number generator (PRNG) with a specific seed.

### Output Format (check.data)
```
%% Section 1
int32_t[2048]: sorted array (non-decreasing order)
```

Each `check.data` contains the corresponding sorted array in non-decreasing order.

### Verification Method
The `check_data()` function in `local_support.c` verifies correctness by:
1. **Sortedness Check**: Ensures `a[i-1] ≤ a[i]` for all i
2. **Sum Preservation**: Ensures sum of elements matches reference (detects missing/extra elements)

## Usage

### Test Single Size

```bash
./EX1_optimized_codes/sort_gcc \
    input_data/mini/input/input.data \
    input_data/mini/output/check.data
```

Expected output: `Success.`

### Test All Sizes

```bash
for size in mini small medium large extra-large; do
    echo "Testing $size..."
    ./EX1_optimized_codes/sort_gcc \
        input_data/$size/input/input.data \
        input_data/$size/output/check.data
done
```

Expected output: `Success.` for all sizes.

### Compare Performance (Optional)

```bash
for size in mini small medium large extra-large; do
    echo -n "$size: "
    time ./EX1_optimized_codes/sort_gcc \
        input_data/$size/input/input.data \
        input_data/$size/output/check.data
done
```

**Note**: Since all datasets have the same size, execution times should be similar across all "sizes".

## Regeneration

To regenerate all datasets from scratch:

```bash
# 1. Ensure baseline is compiled
make clean && make baseline

# 2. Run generation script
bash generate_all_data.sh
```

The script will:
1. Generate `input.data` for each size with different random seeds
2. Use the baseline executable to produce `check.data` (golden output)
3. Verify all datasets pass correctness tests

## Why Different Random Patterns?

Even though merge sort has O(n log n) complexity in all cases, different input distributions can still affect:

1. **Cache Behavior**: Different value distributions may lead to different cache access patterns
2. **Branch Prediction**: The `if(tmp_j < tmp_i)` branch in the merge function behaves differently
3. **Correctness Testing**: Ensures the algorithm works correctly across diverse inputs
4. **Compiler Optimization Testing**: Different patterns may trigger different compiler optimizations

### Pattern Characteristics

| Size        | Seed | Expected Distribution | Sort Difficulty |
|-------------|------|-----------------------|-----------------|
| mini        | 1    | Pseudo-random         | Baseline        |
| small       | 42   | Different random      | Similar         |
| medium      | 123  | Different random      | Similar         |
| large       | 456  | Different random      | Similar         |
| extra-large | 789  | Different random      | Similar         |

**Note**: Merge sort's time complexity is independent of input order (always O(n log n)), unlike quicksort or insertion sort.

## Fixed Size Rationale

The benchmark uses a fixed size (`SIZE 2048`) because:

1. **Hardware Synthesis**: MachSuite is designed for FPGA high-level synthesis (HLS), which requires compile-time known array sizes
2. **Fair Comparison**: Consistent size enables fair performance comparison across optimizations
3. **Memory Layout**: Fixed size allows static memory allocation, avoiding dynamic allocation overhead
4. **Algorithm Standard**: The implementation follows a standard merge sort pattern with fixed-size buffers

## Merge Sort Implementation Details

### Bottom-Up Approach

This benchmark uses a **bottom-up (iterative)** merge sort instead of the classic top-down recursive version:

```
Pass 1: Merge subarrays of size 1 → arrays of size 2
Pass 2: Merge subarrays of size 2 → arrays of size 4
Pass 3: Merge subarrays of size 4 → arrays of size 8
...
Pass 11: Merge subarrays of size 1024 → array of size 2048
```

**Advantages of Bottom-Up:**
- No recursion overhead (no function call stack)
- More predictable control flow
- Better suited for hardware synthesis (FPGA)
- Easier to pipeline and parallelize

### Merge Operation

The core `merge()` function combines two sorted subarrays using a clever two-pointer technique:

```c
void merge(TYPE a[SIZE], int start, int m, int stop) {
    TYPE temp[SIZE];
    
    // Copy first half normally
    for(i=start; i<=m; i++)
        temp[i] = a[i];
    
    // Copy second half in REVERSE
    for(j=m+1; j<=stop; j++)
        temp[m+1+stop-j] = a[j];
    
    // Merge from both ends toward center
    i = start; j = stop;
    for(k=start; k<=stop; k++) {
        if(temp[j] < temp[i])
            a[k] = temp[j--];
        else
            a[k] = temp[i++];
    }
}
```

**Key Insight**: By copying the second half in reverse, we eliminate the need for boundary checks during merging. The largest elements act as sentinels for each other.

## Performance Characteristics

### Computational Complexity

For SIZE=2048:
- **Passes**: log₂(2048) = 11
- **Comparisons per pass**: ~2048
- **Total comparisons**: ~22,500
- **Memory accesses**: ~45,000 reads + ~22,500 writes

### Memory Access Pattern

```
Pass 1:  [0,1][2,3][4,5]... → Sequential, excellent cache locality
Pass 2:  [0-3][4-7][8-11]... → Still good locality
Pass 3:  [0-7][8-15]... → Moderate locality
...
Pass 11: [0-1023][1024-2047] → Large stride, poor cache locality
```

**Observation**: Cache performance degrades as merge size increases.

### Optimization Opportunities

1. **Loop Unrolling**: Unroll merge loops for better ILP
2. **SIMD**: Vectorize comparisons using SIMD instructions
3. **Cache Blocking**: Organize merges to fit in cache
4. **Prefetching**: Insert prefetch hints for large merges
5. **Parallel Merging**: Independent merges can run in parallel
6. **Hardware Pipelining**: Pipeline merge stages in FPGA

## Comparison with Other Sorting Algorithms

| Algorithm      | Time Complexity | Space | Stability | Cache | HLS-Friendly |
|----------------|-----------------|-------|-----------|-------|--------------|
| Merge Sort     | O(n log n)      | O(n)  | Yes       | Good  | ✓✓✓          |
| Quick Sort     | O(n log n)*     | O(1)  | No        | Good  | ✗ (recursive)|
| Heap Sort      | O(n log n)      | O(1)  | No        | Poor  | ✓✓           |
| Insertion Sort | O(n²)           | O(1)  | Yes       | Good  | ✓✓✓          |
| Radix Sort     | O(nk)           | O(n)  | Yes       | Good  | ✓✓           |

*O(n²) worst case for quicksort

**Why Merge Sort for HLS:**
- Predictable control flow (no recursion, no worst cases)
- Regular memory access patterns
- Easy to pipeline and parallelize
- Stable performance across all inputs

## Educational Value

This benchmark demonstrates several important concepts:

### Algorithm Design
- **Divide and Conquer**: Breaking problems into smaller subproblems
- **Iterative vs Recursive**: Bottom-up avoids recursion overhead
- **Sentinel Technique**: Reverse copy eliminates boundary checks

### Performance Analysis
- **Time-Space Tradeoff**: O(n) space for O(n log n) time
- **Cache Effects**: How merge size affects cache performance
- **Predictability**: Why consistent complexity is valuable

### Hardware Synthesis
- **Static Memory**: Compile-time known sizes for FPGA synthesis
- **Pipeline Opportunities**: Where and how to pipeline operations
- **Parallelism**: Independent merges can run concurrently

### Software Optimization
- **Loop Optimization**: Unrolling, vectorization opportunities
- **Memory Optimization**: Access pattern improvements
- **Branch Prediction**: Impact of comparison patterns

## Historical Context

Merge sort was invented by John von Neumann in 1945, making it one of the earliest sorting algorithms. Its significance:

- **First O(n log n) algorithm**: Proved optimal for comparison-based sorting
- **Divide-and-conquer paradigm**: Influenced countless later algorithms
- **External sorting**: Foundation for sorting data larger than memory
- **Parallel algorithms**: Natural parallelism inspired parallel sorting research

The bottom-up variant used in this benchmark was developed to eliminate recursion, making it suitable for:
- Early computers with limited stack space
- Embedded systems
- Hardware implementations (FPGA/ASIC)

## Files in This Directory

- `README.md` (this file): Complete documentation
- `generate_all_data.sh`: Script to regenerate all datasets
- `mini/`, `small/`, `medium/`, `large/`, `extra-large/`: Dataset directories

## References

1. **Original Paper**: von Neumann, J. (1945). "First Draft of a Report on the EDVAC"
2. **MachSuite**: Reagen, B., et al. (2014). "MachSuite: Benchmarks for accelerator design and customized architectures"
3. **Algorithm Analysis**: Knuth, D.E. "The Art of Computer Programming, Vol. 3: Sorting and Searching"

## Notes

- All random values are generated using the MachSuite PRNG (`prng_rand`)
- Values are masked with `TYPE_MAX` to ensure positive int32_t values
- The `check_data()` function uses both sortedness and sum checks for robustness
- Execution time should be nearly identical across all "sizes" since array size is constant

---

**Generated**: November 2024  
**Benchmark**: MachSuite sort-merge-mach  
**Algorithm**: Bottom-up Merge Sort  
**Array Size**: 2048 int32_t (FIXED)

