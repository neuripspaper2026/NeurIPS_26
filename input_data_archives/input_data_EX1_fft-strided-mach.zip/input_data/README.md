# FFT (Strided) Test Datasets

This directory contains 5 test datasets for the FFT (Fast Fourier Transform) benchmark using the strided memory access pattern.

## ⚠️ Important: About "Size"

Due to the **fixed FFT size** defined by the algorithm (FFT_SIZE=1024), all test sets have **exactly the same input size**.

The different "sizes" represent different **random input patterns** for correctness validation, NOT different computational scales. All datasets contain 1024 complex numbers (2048 floating-point values: real + imaginary parts) plus 512 twiddle factors.

---

## Dataset Description

**Important: All datasets have identical dimensions (FFT_SIZE=1024).**

This is because the FFT size is determined by the `FFT_SIZE` constant in `fft.h`:
- Input: 1024 complex numbers (real[1024] + img[1024])
- Twiddle factors: 512 complex numbers (real_twid[512] + img_twid[512])
- Output: 1024 complex numbers after FFT transformation

| Size | Pattern | Random Seed | Description |
|------|---------|-------------|-------------|
| **mini** | Standard | 1 | Original random pattern (matches root `input.data`) |
| **small** | Alternative | 42 | Different random input distribution |
| **medium** | Variant | 123 | Another random pattern |
| **large** | Variant | 456 | Yet another random distribution |
| **extra-large** | Variant | 789 | Fifth random pattern variant |

All datasets use:
- Different random seeds to generate diverse input patterns
- Same twiddle factors (pre-calculated from cos/sin functions)
- Random real and imaginary parts in range [0, 1]

### Sample Input Values (First 5 Real Components)

| Size | Real[0:4] Values |
|------|------------------|
| mini | 0.931647, 0.074914, 0.324313, 0.488922, 0.200322 |
| small | 0.107907, 0.436979, 0.910748, 0.180377, 0.185787 |
| medium | 0.456126, 0.859595, 0.337608, 0.546422, 0.596097 |
| large | 0.887694, 0.263684, 0.759144, 0.162387, 0.282924 |
| extra-large | 0.319262, 0.667773, 0.180679, 0.778351, 0.969751 |

These different input patterns test the FFT algorithm's correctness across various signal characteristics.

### Data Format

**Input (`input.data`):**
- Section 1: Real parts (1024 × double)
- Section 2: Imaginary parts (1024 × double)
- Section 3: Real twiddle factors (512 × double)
- Section 4: Imaginary twiddle factors (512 × double)

**Output (`check.data`):**
- Section 1: Transformed real parts (1024 × double)
- Section 2: Transformed imaginary parts (1024 × double)

### Why Different Patterns Matter

Even with the same FFT size, different input patterns test:
- **Numerical stability:** Different magnitudes and phases
- **Floating-point precision:** Various combinations of values
- **Algorithm correctness:** Edge cases and typical cases
- **Memory access patterns:** Different data distributions affect cache behavior

This ensures the strided FFT implementation is robust across diverse signal types.

---

## Usage

### Test Single Dataset

```bash
# Test mini dataset
./EX1_optimized_codes/fft_gcc \
    input_data/mini/input/input.data \
    input_data/mini/output/check.data
```

Expected output: `Success.`

### Test All Datasets

```bash
# Test all sizes
for size in mini small medium large extra-large; do
    echo "Testing $size..."
    ./EX1_optimized_codes/fft_gcc \
        input_data/$size/input/input.data \
        input_data/$size/output/check.data
done
```

Expected: All tests should print `Success.`

### Batch Testing

```bash
# Compile baseline first
make clean && make all

# Run tests
./EX1_optimized_codes/fft_gcc input_data/mini/input/input.data input_data/mini/output/check.data
./EX1_optimized_codes/fft_gcc input_data/small/input/input.data input_data/small/output/check.data
./EX1_optimized_codes/fft_gcc input_data/medium/input/input.data input_data/medium/output/check.data
./EX1_optimized_codes/fft_gcc input_data/large/input/input.data input_data/large/output/check.data
./EX1_optimized_codes/fft_gcc input_data/extra-large/input/input.data input_data/extra-large/output/check.data
```

---

## Regeneration

To regenerate all datasets with fresh random patterns:

### Method 1: Using the provided script (Recommended)

```bash
./generate_all_data.sh
```

This script will:
1. Generate 5 different input patterns with different random seeds
2. Compile the baseline program
3. Generate golden outputs (`check.data`) for each pattern
4. Verify all datasets

### Method 2: Manual generation

```bash
# 1. Compile baseline
make clean && make all

# 2. Modify generate.c to use different seeds, then:
for size in mini small medium large extra-large; do
    # Edit generate.c to change the random seed
    # Recompile and run generator
    make generate
    mv input.data input_data/$size/input/input.data
    
    # Generate golden output
    ./EX1_optimized_codes/fft_gcc \
        input_data/$size/input/input.data \
        input_data/$size/input/input.data
    cp EX5_correctness/output_gcc.data input_data/$size/output/check.data
done
```

---

## Verification

After regeneration, verify all datasets:

```bash
for size in mini small medium large extra-large; do
    echo -n "[$size] "
    ./EX1_optimized_codes/fft_gcc \
        input_data/$size/input/input.data \
        input_data/$size/output/check.data && echo "PASS" || echo "FAIL"
done
```

All tests should show `Success.` and `PASS`.

---

## Technical Details

### FFT Algorithm: Strided Access Pattern

This implementation uses a **strided memory access pattern**, which is different from the transpose-based FFT:
- **Memory Access:** Non-contiguous (strided) access to array elements
- **Cache behavior:** Different from sequential access patterns
- **Optimization challenge:** Strided access can be less cache-friendly

### Input Generation

Random inputs are generated using:
```c
prng_srand(SEED_VALUE, &state);
for(i=0; i<FFT_SIZE; i++){
    real[i] = (double)prng_rand(&state) / (double)PRNG_RAND_MAX;  // [0, 1]
    img[i] = (double)prng_rand(&state) / (double)PRNG_RAND_MAX;   // [0, 1]
}
```

### Twiddle Factors

Twiddle factors are pre-calculated from trigonometric functions:
```c
for(n=0; n<(FFT_SIZE>>1); n++){
    double angle = 2*PI*n/FFT_SIZE;
    real_twid[n] = cos(angle);
    img_twid[n] = -sin(angle);
}
```

These are **identical across all datasets** since they depend only on FFT_SIZE, not on input data.

### File Sizes

Each dataset consists of:
- `input.data`: ~3,076 lines (~60 KB)
  - 1024 real values
  - 1024 imaginary values
  - 512 real twiddle factors
  - 512 imaginary twiddle factors
- `check.data`: ~2,050 lines (~40 KB)
  - 1024 transformed real values
  - 1024 transformed imaginary values

---

## Algorithm Notes

### FFT Complexity
- **Time:** O(N log N) where N = FFT_SIZE = 1024
- **Space:** O(N)
- **Stages:** log₂(1024) = 10 butterfly stages

### Strided vs Transpose
- **Strided FFT:** Processes data in-place with non-contiguous memory access
- **Transpose FFT:** Rearranges data for better cache locality
- Both produce identical results but with different memory access patterns

---

## Notes

1. **Deterministic Generation:** Each seed produces a deterministic input pattern
2. **Floating-Point Precision:** Uses double-precision (64-bit) arithmetic
3. **Twiddle Factors:** Pre-calculated to avoid runtime trigonometric computations
4. **Output Validation:** Golden outputs are generated by the verified baseline program
5. **Memory Pattern:** Strided access tests different optimization opportunities than sequential access

---

## Why Fixed Size?

FFT size is typically fixed in hardware implementations for several reasons:
- **Hardware optimization:** Fixed-size FFTs enable specialized hardware designs
- **Performance:** Compile-time constants allow aggressive compiler optimizations
- **Practical use:** Many signal processing applications use standard FFT sizes (powers of 2)

Common FFT sizes: 128, 256, 512, **1024**, 2048, 4096...

---

## References

- Cooley–Tukey FFT algorithm
- Radix-2 decimation-in-frequency (DIF) FFT
- Strided memory access patterns in FFT implementations

