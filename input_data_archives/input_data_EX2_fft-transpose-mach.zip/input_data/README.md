# FFT-Transpose-Mach Dataset Documentation

This directory contains test datasets for the **FFT-Transpose-Mach** benchmark, which implements a 1D Fast Fourier Transform using a transpose-based memory access pattern.

---

## ⚠️ Important: About "Size"

Due to the algorithm's design and the use of fixed-size arrays (512-point FFT), all test sets for `fft-transpose-mach` have **exactly the same input size** (512 complex numbers = 1024 double values).

The different "sizes" (mini, small, medium, large, extra-large) represent different input signal **patterns** generated with varying random seeds for correctness validation, NOT different computational scales. This approach allows for testing the algorithm's behavior across diverse input data while maintaining a consistent execution environment.

---

## Dataset Structure

```
input_data/
├── mini/
│   ├── input/input.data     (1027 lines: 2 sections × 512 values + headers)
│   └── output/check.data    (1027 lines: FFT output)
├── small/
├── medium/
├── large/
├── extra-large/
└── README.md (this file)
```

---

## Dataset Details

| Size        | Random Seed | Description                               | Sample Input (First 5 real values) |
|-------------|-------------|-------------------------------------------|------------------------------------|
| mini        | 1           | Standard random pattern (original seed)   | (depends on PRNG) |
| small       | 42          | Alternative random distribution           | (different pattern) |
| medium      | 123         | Different random pattern                  | (different pattern) |
| large       | 456         | Another random distribution               | (different pattern) |
| extra-large | 789         | Fifth random pattern                      | (different pattern) |

**Key Points:**
- All datasets: 512-point FFT (fixed)
- Input format: 2 sections (real part, imaginary part)
- Each section: 512 double-precision floating-point values
- Values range: [0.0, 1.0] (normalized random)
- Precision: `double` (1e-6 tolerance for validation)

---

## Algorithm Information

### FFT-Transpose Algorithm
- **Type**: Transpose-based memory access pattern
- **Size**: 512 points (fixed)
- **Complexity**: O(N log N) = O(512 × 9) = O(4608) operations
- **Precision**: Double-precision floating-point
- **Stages**: 9 butterfly stages
- **Memory Pattern**: Uses transpose to optimize cache locality

### Difference from FFT-Strided
- **FFT-Strided**: Accesses memory with stride pattern (non-contiguous)
- **FFT-Transpose**: Uses explicit transpose operations for better locality
- Both implement the same mathematical FFT, but with different optimization strategies

---

## Usage

### Test Single Size
```bash
./EX1_optimized_codes/fft_gcc \
    input_data/mini/input/input.data \
    input_data/mini/output/check.data
```

Expected output: `Success.`

### Test All Sizes
```bash
for size in mini small medium large extra-large; do
    echo "Testing $size..."
    ./EX1_optimized_codes/fft_gcc \
        input_data/$size/input/input.data \
        input_data/$size/output/check.data
done
```

### Run with Custom Executable
```bash
# Test an optimized variant
./EX1_optimized_codes/fft_gcc_optimized \
    input_data/medium/input/input.data \
    input_data/medium/output/check.data
```

---

## Data Format

### Input Data (`input.data`)
```
%% Section 1
<512 double values: real part of input signal>

%% Section 2
<512 double values: imaginary part of input signal>
```

### Output Data (`check.data`)
```
%% Section 1
<512 double values: real part of FFT result>

%% Section 2
<512 double values: imaginary part of FFT result>
```

### Validation
- Comparison uses epsilon tolerance: `EPSILON = 1.0e-6`
- Both real and imaginary parts must match within tolerance

---

## Regeneration

To regenerate all datasets from scratch:

```bash
# 1. Ensure baseline is compiled
make clean
make baseline

# 2. Run generation script
./generate_all_data.sh
```

This will:
1. Create directory structure
2. Generate 5 different input patterns (using different random seeds)
3. Use baseline executable to compute golden outputs
4. Verify all datasets pass correctness tests

---

## Technical Notes

### Why Fixed Size?
The FFT algorithm is optimized for power-of-2 sizes (512 = 2^9). The implementation uses:
- Hardcoded array sizes: `TYPE work_x[512]`, `TYPE work_y[512]`
- Specialized butterfly operations for 512-point FFT
- Fixed transpose patterns

Changing the size would require modifying the algorithm implementation, not just input data.

### Random Pattern Variation
Different random seeds produce different input signals, which test:
- Numerical stability across diverse input ranges
- Edge cases in FFT computation
- Correctness of transpose and butterfly operations
- Cache behavior with different data patterns

---

## File Sizes

Each dataset:
- `input.data`: ~19 KB (1027 lines)
- `check.data`: ~20 KB (1027 lines)

Total: ~195 KB for all 5 datasets

---

## Validation Results

All datasets have been verified to produce correct outputs:
- ✓ mini
- ✓ small
- ✓ medium
- ✓ large
- ✓ extra-large

---

## References

- Implementation based on: V. Volkov and B. Kazian. "Fitting FFT onto the G80 architecture." 2008.
- MachSuite benchmark suite
- Original dataset: Single pattern with seed=1
