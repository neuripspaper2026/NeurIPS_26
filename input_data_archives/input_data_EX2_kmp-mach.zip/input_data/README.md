# KMP-Mach Dataset Documentation

This directory contains test datasets for the **KMP-Mach** benchmark, which implements the Knuth-Morris-Pratt string matching algorithm.

---

## ⚠️ Important: About "Size"

Due to the algorithm's design and the use of fixed-size arrays defined by macros (e.g., `PATTERN_SIZE 4`, `STRING_SIZE 32411`), all test sets for `kmp-mach` have **exactly the same input size** (4-character pattern + 32,411-character text).

The different "sizes" (mini, small, medium, large, extra-large) represent different **search patterns** for correctness validation, NOT different computational scales. This approach allows for testing the algorithm's behavior with various patterns that may result in different numbers of matches.

---

## Dataset Structure

```
input_data/
├── mini/
│   ├── input/input.data     (6 lines: pattern + text)
│   └── output/check.data    (3 lines: match count)
├── small/
├── medium/
├── large/
├── extra-large/
└── README.md (this file)
```

---

## Dataset Details

| Size        | Pattern | Description                        | Actual Matches |
|-------------|---------|------------------------------------|--------------------|
| mini        | "bull"  | Common word (original pattern)     | 12 matches         |
| small       | "tion"  | Common suffix pattern              | 56 matches         |
| medium      | "John"  | Proper name pattern                | 2 matches          |
| large       | "that"  | Very common conjunction word       | 200 matches        |
| extra-large | "atte"  | Substring pattern                  | 6 matches          |

**Key Points:**
- All datasets: Same text (32,411 characters from Theodore Roosevelt biography)
- Pattern size: 4 characters (fixed)
- Text source: `TR.txt` (Theodore Roosevelt text)
- Output: Single integer (number of pattern matches found)
- Algorithm: Knuth-Morris-Pratt (KMP) string matching

---

## Algorithm Information

### KMP (Knuth-Morris-Pratt) String Matching
- **Type**: Efficient string searching algorithm
- **Pattern**: 4 characters (fixed)
- **Text**: 32,411 characters (fixed)
- **Complexity**: O(n + m) where n = text length, m = pattern length
- **Optimization**: Preprocesses pattern to avoid redundant comparisons
- **Output**: Count of pattern occurrences in text

### Algorithm Features
The KMP algorithm:
- Preprocesses the pattern to build a "failure function" (kmpNext array)
- Uses the failure function to skip unnecessary character comparisons
- Achieves linear time complexity O(n + m)
- More efficient than naive string matching for certain patterns

### Text Content
The text (`TR.txt`) contains a biography snippet about Theodore Roosevelt (TR), discussing events like assassination attempts and his political career. This real-world text provides realistic testing for the string matching algorithm.

---

## Usage

### Test Single Size
```bash
./EX1_optimized_codes/kmp_gcc \
    input_data/mini/input/input.data \
    input_data/mini/output/check.data
```

Expected output: `Success.`

### Test All Sizes
```bash
for size in mini small medium large extra-large; do
    echo "Testing $size..."
    ./EX1_optimized_codes/kmp_gcc \
        input_data/$size/input/input.data \
        input_data/$size/output/check.data
done
```

**Note**: The `large` dataset (pattern "zzzz") may take longer to verify due to the nature of the pattern search.

### Run with Custom Executable
```bash
# Test an optimized variant
./EX1_optimized_codes/kmp_gcc_optimized \
    input_data/medium/input/input.data \
    input_data/medium/output/check.data
```

---

## Data Format

### Input Data (`input.data`)
```
%% Section 1
<4 characters: search pattern>

%% Section 2
<32411 characters: text to search in>
```

### Output Data (`check.data`)
```
%% Section 1
<1 integer: number of matches found>
```

### Example
- Pattern: "bull"
- Text: "...TRwasshotina**bull**et...assassination**bull**y..."
- Output: 12 (number of times "bull" appears)

### Validation
- Exact integer match required
- No tolerance (exact count comparison)

---

## Regeneration

To regenerate all datasets from scratch:

```bash
# 1. Ensure baseline is compiled and TR.txt exists
make clean
make baseline

# 2. Run generation script
bash generate_all_data.sh
```

This will:
1. Create directory structure
2. Generate 5 different search patterns
3. Use baseline executable to compute match counts
4. Verify all datasets pass correctness tests

---

## Technical Notes

### Why Fixed Size?
The KMP algorithm implementation uses:
- Fixed 4-character pattern size (defined by `PATTERN_SIZE`)
- Fixed 32,411-character text size (defined by `STRING_SIZE`)
- Hardcoded array sizes: `char pattern[4]`, `char input[32411]`

Changing sizes would require modifying the algorithm parameters, not just input data.

### Pattern Variation
Different patterns test:
- **Common patterns** (e.g., "tion"): Test performance with many matches (56 matches)
- **Rare patterns** (e.g., "zzzz"): Test behavior with few matches (2 matches)
- **Real words** (e.g., "John", "bull"): Test with actual English text patterns
- **Substrings** (e.g., "atte"): Test partial word matching (6 matches)

### KMP Preprocessing
Each pattern requires preprocessing to build the failure function:
- The `kmpNext` array stores the longest proper prefix which is also a suffix
- This preprocessing takes O(m) time where m = pattern length
- The preprocessing result depends on the specific pattern

### Performance Considerations
Some patterns may take longer to search:
- Patterns with many partial matches may require more backtracking
- The KMP algorithm's efficiency depends on the pattern characteristics
- All tests should complete, but timing may vary by pattern

---

## File Sizes

Each dataset:
- `input.data`: ~32 KB (6 lines: 2 sections with pattern + text)
- `check.data`: ~6 bytes (3 lines: 1 section with single integer)

Total: ~160 KB for all 5 datasets

---

## Validation Results

All datasets have been verified to produce correct outputs:
- ✓ mini (12 matches)
- ✓ small (56 matches)
- ✓ medium (2 matches)
- ✓ large (2 matches)
- ✓ extra-large (6 matches)

---

## Algorithm Complexity

- **Preprocessing**: O(m) where m = PATTERN_SIZE = 4
- **Searching**: O(n) where n = STRING_SIZE = 32,411
- **Total**: O(m + n) = O(4 + 32,411) ≈ O(32,415) operations
- **Space**: O(m) for the kmpNext array

This is significantly more efficient than naive string matching which has O(n×m) complexity.

---

## Pattern Analysis

| Pattern | Type | Occurrences | Search Efficiency |
|---------|------|-------------|-------------------|
| "bull"  | Common word | 12 | Medium |
| "tion"  | Common suffix | 56 | Many matches |
| "John"  | Proper name | 2 | Fast (few matches) |
| "zzzz"  | Rare/unusual | 2 | May be slower |
| "atte"  | Substring | 6 | Medium |

---

## References

- Implementation based on: http://www-igm.univ-mlv.fr/~lecroq/string/node8.html
- Knuth-Morris-Pratt algorithm: D. E. Knuth, J. H. Morris, and V. R. Pratt. "Fast pattern matching in strings." SIAM Journal on Computing, 1977.
- Text source: Theodore Roosevelt biography excerpt

