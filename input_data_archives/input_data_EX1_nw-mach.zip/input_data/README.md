# NW-Mach Dataset Documentation

This directory contains test datasets for the **NW-Mach** benchmark, which implements the Needleman-Wunsch algorithm for global sequence alignment in bioinformatics.

---

## ⚠️ Important: About "Size"

Due to the algorithm's design and the use of fixed-size arrays defined by macros (e.g., `ALEN 128`, `BLEN 128`), all test sets for `nw-mach` have **exactly the same input size** (two DNA sequences of 128 characters each).

The different "sizes" (mini, small, medium, large, extra-large) represent different **DNA sequence pairs** generated with varying random seeds for correctness validation, NOT different computational scales. This approach allows for testing the algorithm's behavior across diverse sequence comparisons while maintaining a consistent execution environment.

---

## Dataset Structure

```
input_data/
├── mini/
│   ├── input/input.data     (~267B: 2 DNA sequences)
│   └── output/check.data    (~523B: aligned sequences)
├── small/
├── medium/
├── large/
├── extra-large/
└── README.md (this file)
```

---

## Dataset Details

| Size        | Random Seed | Description                               | Sequence Characteristics |
|-------------|-------------|-------------------------------------------|--------------------------|
| mini        | 1           | Standard DNA sequences (original)         | Varies by seed           |
| small       | 42          | Alternative sequence pair                 | Varies by seed           |
| medium      | 123         | Different sequence pattern                | Varies by seed           |
| large       | 456         | Another DNA sequence pair                 | Varies by seed           |
| extra-large | 789         | Fifth DNA sequence pair                   | Varies by seed           |

**Key Points:**
- All datasets: Two sequences of 128 characters each (256 total input chars)
- DNA alphabet: {a, c, g, t} (adenine, cytosine, guanine, thymine)
- Output: Aligned sequences (up to 256 characters each with gaps)
- Different seeds produce different sequence compositions
- Algorithm finds optimal global alignment using dynamic programming

---

## Algorithm Overview

### Needleman-Wunsch (Global Sequence Alignment)

**Purpose:**  
Find the optimal global alignment between two biological sequences (DNA, RNA, or protein) by maximizing similarity or minimizing edit distance.

**Key Features:**
- **Global Alignment**: Aligns sequences from end to end
- **Dynamic Programming**: Uses a 2D matrix to compute optimal alignment
- **Scoring System**: Assigns scores for matches, mismatches, and gaps
- **Optimal Solution**: Guarantees finding the best alignment

**Complexity:**
- Time: O(n × m) where n=128, m=128 → O(16,384) operations
- Space: O(n × m) → (129 × 129 = 16,641 cells) for DP matrix
- **Use Case**: Essential for comparing genes, proteins, and evolutionary analysis

**Algorithm Steps:**
1. **Initialization**: Create (n+1) × (m+1) scoring matrix
2. **Fill Matrix**: Compute scores using recurrence relation
3. **Scoring**: Match/mismatch/gap penalties
4. **Traceback**: Follow pointers to reconstruct optimal alignment
5. **Output**: Two aligned sequences with inserted gaps

---

## Data Format

### Input (`input.data`):

```
%% Section 1: Sequence A (128 characters)
seqA[ALEN]  # First DNA sequence (e.g., "acgt...")

%% Section 2: Sequence B (128 characters)
seqB[BLEN]  # Second DNA sequence (e.g., "tgca...")
```

**Total size**: ~267 bytes per input file

### Output (`check.data`):

```
%% Section 1: Aligned Sequence A (up to 256 characters)
alignedA[ALEN+BLEN]  # First sequence with gaps inserted

%% Section 2: Aligned Sequence B (up to 256 characters)
alignedB[ALEN+BLEN]  # Second sequence with gaps inserted
```

**Total size**: ~523 bytes per output file

### Validation:
- Method: Exact string comparison (`memcmp`)
- Checks: Both aligned sequences must match exactly
- No tolerance: Alignments must be character-perfect

---

## Biological Background

### DNA Sequences

DNA (Deoxyribonucleic Acid) is composed of four nucleotides:
- **A** (Adenine): Pairs with T
- **C** (Cytosine): Pairs with G
- **G** (Guanine): Pairs with C
- **T** (Thymine): Pairs with A

**Sequence Alignment** is fundamental in bioinformatics for:
1. **Gene Comparison**: Identifying similar genes across species
2. **Evolution**: Tracing evolutionary relationships
3. **Function Prediction**: Inferring protein function from similar sequences
4. **Mutation Detection**: Finding genetic variations

### Why Alignment?

Biological sequences evolve through:
- **Substitutions**: One nucleotide replaces another (e.g., A → G)
- **Insertions**: New nucleotides added
- **Deletions**: Nucleotides removed

**Alignment** reveals these evolutionary events by:
- Placing similar characters in same columns
- Inserting gaps (-) to account for insertions/deletions
- Maximizing overall similarity score

---

## Needleman-Wunsch Algorithm

### Dynamic Programming Formulation

**Scoring Matrix M[i][j]:**

```
M[i][j] = max {
    M[i-1][j-1] + score(seqA[i], seqB[j]),  # Match/mismatch
    M[i-1][j]   + gap_penalty,               # Gap in seqB
    M[i][j-1]   + gap_penalty                # Gap in seqA
}
```

Where:
- `score(a, b)` = match score if a=b, mismatch penalty if a≠b
- `gap_penalty` = penalty for inserting a gap (negative)

**Initialization:**
```
M[0][0] = 0
M[i][0] = i × gap_penalty  (for i = 1 to ALEN)
M[0][j] = j × gap_penalty  (for j = 1 to BLEN)
```

**Traceback:**
Follow pointers from M[ALEN][BLEN] back to M[0][0] to reconstruct alignment.

### Scoring Scheme

This implementation uses:
- **Match**: +1
- **Mismatch**: -1
- **Gap**: -1

(Note: Scoring parameters may vary; check `nw.c` for exact values)

### Example

**Input:**
```
SeqA: ACGT
SeqB: ACT
```

**Scoring Matrix:**
```
    -   A   C   T
-   0  -1  -2  -3
A  -1   1   0  -1
C  -2   0   2   1
G  -3  -1   1   1
T  -4  -2   0   2
```

**Optimal Alignment:**
```
SeqA: ACGT
      ||| 
SeqB: AC-T
```

Score: 1+1-1+1 = 2

---

## Comparison: Needleman-Wunsch vs Smith-Waterman

| Feature | Needleman-Wunsch | Smith-Waterman |
|---------|------------------|----------------|
| **Alignment Type** | Global (end-to-end) | Local (best substring) |
| **Use Case** | Whole sequence comparison | Finding conserved regions |
| **Initialization** | M[0][j], M[i][0] = gaps | M[i][j] = max(0, ...) |
| **Traceback Start** | M[n][m] (bottom-right) | Max value in matrix |
| **Complexity** | O(n×m) time, O(n×m) space | O(n×m) time, O(n×m) space |
| **Applications** | Full gene alignment | Motif finding |

**This benchmark**: Needleman-Wunsch (global alignment)

---

## Dataset Characteristics

### Sequence Generation

Each dataset has unique DNA sequences due to different random seeds:

**Generation Process:**
1. Initialize PRNG with specific seed
2. For each position in sequence A (128 chars):
   - Randomly select from {a, c, g, t}
3. For each position in sequence B (128 chars):
   - Randomly select from {a, c, g, t}
4. Write sequences to input file

**Properties:**
- **Random Composition**: Nucleotides uniformly distributed
- **No Bias**: Each of 4 nucleotides equally likely
- **Independent**: SeqA and SeqB generated independently
- **Fixed Length**: Always 128 characters per sequence

### Why Different Seeds Matter

Different random seeds produce:
- **Varied Similarity**: Some sequences more similar than others
- **Different Alignments**: Various gap patterns and positions
- **Scoring Diversity**: Different optimal scores
- **Edge Cases**: Testing algorithm on diverse input patterns

This diversity ensures the algorithm is tested across realistic biological scenarios.

---

## Usage

### Test Single Dataset:

```bash
./EX1_optimized_codes/nw_gcc \
    input_data/mini/input/input.data \
    input_data/mini/output/check.data
```

**Expected output:**
```
Success.
```

### Test All Datasets:

```bash
for size in mini small medium large extra-large; do
    echo "Testing $size..."
    ./EX1_optimized_codes/nw_gcc \
        input_data/$size/input/input.data \
        input_data/$size/output/check.data
done
```

### Regenerate All Data:

```bash
# From nw-mach directory
bash generate_all_data.sh
```

---

## Performance Considerations

### Computational Characteristics

**Dominant Operations:**
- Matrix filling: 16,641 cells × (3 comparisons + 1 max) ≈ 66K ops
- Scoring: Character comparisons and arithmetic
- Traceback: O(n+m) = O(256) pointer following

**Memory Access Pattern:**
- **Fill Phase**: Row-major traversal (good cache locality)
- **Traceback**: Reverse diagonal traversal (poor locality)
- **Data Structures**: 2D arrays (M and ptr matrices)

**Optimization Opportunities:**
- Vectorize cell computations (SIMD)
- Loop tiling for better cache usage
- Space optimization: Only keep 2 rows instead of full matrix
- Parallelize row/diagonal computations

### Expected Runtime (O3 optimization):
- Mini/Small/Medium/Large/Extra-large: ~1-5 ms (all same size)
- Variation: ±10% due to different traceback paths

---

## Applications in Bioinformatics

### Real-World Uses

**1. Evolutionary Biology**
   - Phylogenetic tree construction
   - Species relationship analysis
   - Gene orthology identification

**2. Medicine**
   - Disease gene discovery
   - Personalized medicine (genome comparison)
   - Drug target identification

**3. Genomics**
   - Genome assembly
   - Variant calling
   - Reference alignment

**4. Proteomics**
   - Protein family classification
   - Structure prediction
   - Function annotation

---

## Limitations of This Benchmark

**Simplified Model:**
- Fixed sequences (128×128) - real genomes have millions of bases
- Simple scoring (uniform match/mismatch) - real biology uses complex matrices
- No affine gap penalties - real alignments use different costs for gap open/extend
- DNA only - proteins use 20 amino acids with substitution matrices (BLOSUM, PAM)

**Not Included:**
- Multiple sequence alignment (aligning >2 sequences)
- Heuristic speedups (BLAST, FASTA) - necessary for large-scale searches
- Profile HMMs (Hidden Markov Models)
- RNA secondary structure considerations

---

## References

### Algorithm Background

- **Needleman-Wunsch**: S. B. Needleman & C. D. Wunsch, J. Mol. Biol. (1970)
- **Dynamic Programming**: Bellman, "Dynamic Programming" (1957)
- **Sequence Alignment**: Mount, "Bioinformatics" (2004)

### Bioinformatics Tools

- **BLAST**: Basic Local Alignment Search Tool (heuristic)
- **ClustalW**: Multiple sequence alignment
- **EMBOSS**: European Molecular Biology Open Software Suite

### Related Benchmarks

- **smith-waterman**: Local alignment (finds best substring match)
- **kmp-mach**: String matching (different problem domain)

---

## Troubleshooting

### Common Issues

**Issue**: "Invalid input: line X of section Y"
- **Cause**: Corrupted input data file
- **Fix**: Regenerate using `bash generate_all_data.sh`

**Issue**: "Benchmark results are incorrect"
- **Cause**: check.data doesn't match computed alignment
- **Fix**: Regenerate check.data using baseline program

**Issue**: Empty aligned sequences
- **Cause**: Potential bug in traceback logic
- **Fix**: Verify baseline program correctness

**Issue**: Alignment contains invalid characters
- **Cause**: Uninitialized memory or buffer overflow
- **Fix**: Check array bounds and initialization

---

## Algorithm Details

### Pseudocode

```python
def needleman_wunsch(seqA, seqB):
    # Initialize scoring matrix
    M = [[0] * (BLEN+1) for _ in range(ALEN+1)]
    ptr = [[0] * (BLEN+1) for _ in range(ALEN+1)]
    
    # Initialize first row and column
    for i in range(1, ALEN+1):
        M[i][0] = i * GAP_PENALTY
        ptr[i][0] = UP
    for j in range(1, BLEN+1):
        M[0][j] = j * GAP_PENALTY
        ptr[0][j] = LEFT
    
    # Fill matrix
    for i in range(1, ALEN+1):
        for j in range(1, BLEN+1):
            match = M[i-1][j-1] + score(seqA[i-1], seqB[j-1])
            delete = M[i-1][j] + GAP_PENALTY
            insert = M[i][j-1] + GAP_PENALTY
            
            M[i][j] = max(match, delete, insert)
            ptr[i][j] = argmax(match, delete, insert)
    
    # Traceback
    alignedA, alignedB = "", ""
    i, j = ALEN, BLEN
    while i > 0 or j > 0:
        if ptr[i][j] == DIAG:
            alignedA = seqA[i-1] + alignedA
            alignedB = seqB[j-1] + alignedB
            i -= 1; j -= 1
        elif ptr[i][j] == UP:
            alignedA = seqA[i-1] + alignedA
            alignedB = '-' + alignedB
            i -= 1
        else:  # LEFT
            alignedA = '-' + alignedA
            alignedB = seqB[j-1] + alignedB
            j -= 1
    
    return alignedA, alignedB
```

---

## Dataset Metadata

| Property | Value |
|----------|-------|
| Benchmark Name | nw-mach |
| Algorithm | Needleman-Wunsch (Global Alignment) |
| Application | Bioinformatics (Sequence Comparison) |
| Input Size | Fixed (128×128 characters) |
| Dataset Count | 5 |
| Total Data Size | ~4 KB (10 files) |
| Validation Method | Exact string match (`memcmp`) |
| Generation Time | ~1 second (all datasets) |
| Verification Time | ~2-5 ms per dataset |

---

## Summary

The **NW-Mach** dataset provides 5 test cases with different DNA sequence pairs for validating Needleman-Wunsch implementations. All datasets maintain the same size (128×128 characters) but vary in sequence composition, ensuring comprehensive testing of the dynamic programming alignment algorithm across diverse biological scenarios.

**Key Takeaways:**
- ✅ Fixed scale: All datasets use 128×128 character sequences
- ✅ Different patterns: 5 random DNA sequence pairs
- ✅ Biologically realistic: Uses DNA alphabet {a, c, g, t}
- ✅ Algorithm test: Global alignment with dynamic programming
- ✅ Applications: Gene comparison, evolutionary analysis, genomics

**Historical Significance:**
The Needleman-Wunsch algorithm (1970) was one of the first applications of dynamic programming to biology and revolutionized sequence analysis. It remains fundamental to computational biology and is taught in every bioinformatics course.

For questions or issues, refer to the MachSuite documentation or regenerate data using the provided script.

