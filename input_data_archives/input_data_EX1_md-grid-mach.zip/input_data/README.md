# MD-Grid-Mach Dataset Documentation

This directory contains test datasets for the **MD-Grid-Mach** benchmark, which implements Molecular Dynamics (MD) simulation using a grid-based spatial partitioning approach for N-body force calculations.

---

## ⚠️ Important: About "Size"

Due to the algorithm's design and the use of fixed-size arrays defined by macros (e.g., `nAtoms 256`, `blockSide 4`, `domainEdge 20.0`), all test sets for `md-grid-mach` have **exactly the same input size** (256 atoms in a 4×4×4 grid).

The different "sizes" (mini, small, medium, large, extra-large) represent different **random atom distributions** (spatial configurations) generated with varying random seeds for correctness validation, NOT different computational scales. This approach allows for testing the algorithm's behavior across diverse molecular configurations while maintaining a consistent execution environment.

---

## Dataset Structure

```
input_data/
├── mini/
│   ├── input/input.data     (~36KB: grid populations + positions)
│   └── output/check.data    (~36KB: force vectors)
├── small/
├── medium/
├── large/
├── extra-large/
└── README.md (this file)
```

---

## Dataset Details

| Size        | Random Seed | Description                               | Grid Distribution Pattern |
|-------------|-------------|-------------------------------------------|---------------------------|
| mini        | 1           | Standard random distribution (original)   | Varies by seed            |
| small       | 42          | Alternative random distribution           | Varies by seed            |
| medium      | 123         | Different random spatial pattern          | Varies by seed            |
| large       | 456         | Another random atom configuration         | Varies by seed            |
| extra-large | 789         | Fifth random distribution                 | Varies by seed            |

**Key Points:**
- All datasets: 256 atoms in a 20.0×20.0×20.0 domain
- Grid structure: 4×4×4 blocks (64 cells total)
- Each cell can hold up to 10 atoms (`densityFactor`)
- Lennard-Jones potential parameters: lj1=1.5, lj2=2.0
- Van der Waals threshold: 1.049² (prevents atom overlap)
- Different seeds produce different spatial distributions

---

## Algorithm Overview

### MD-Grid (Molecular Dynamics with Grid-Based Partitioning)

**Purpose:**  
Calculate inter-atomic forces in a molecular dynamics simulation using the Lennard-Jones potential with spatial partitioning for efficient neighbor searches.

**Key Features:**
- **Grid-Based Partitioning**: Divides the simulation domain into a 4×4×4 grid
- **Spatial Locality**: Only computes forces between nearby atoms (neighboring grid cells)
- **Lennard-Jones Potential**: Models van der Waals forces (attractive/repulsive)
- **N-body Problem**: Computes pairwise forces for all 256 atoms

**Complexity:**
- Naive N-body: O(n²) = O(65,536) comparisons
- Grid-accelerated: O(n × local_density) ≈ O(256 × 27) ≈ O(6,912) comparisons
- **Speedup**: ~9.5× due to spatial partitioning

**Algorithm Steps:**
1. **Binning**: Assign atoms to grid cells based on position
2. **Neighbor Search**: For each atom, search in 27 neighboring cells (3×3×3)
3. **Force Calculation**: Compute Lennard-Jones forces for nearby pairs
4. **Accumulation**: Sum forces acting on each atom

---

## Data Format

### Input (`input.data`):

```
%% Section 1: Grid Populations (64 int32_t values)
n_points[4][4][4]  # Number of atoms in each grid cell

%% Section 2: Atom Positions (1920 double values)
position[4][4][4][10].{x,y,z}  # 3D coordinates for up to 10 atoms per cell
```

**Total size**: ~36 KB per input file

### Output (`check.data`):

```
%% Section 1: Force Vectors (1920 double values)
force[4][4][4][10].{x,y,z}  # 3D force vectors for each atom
```

**Total size**: ~36 KB per output file

### Validation:
- Epsilon: 1.0e-6 (floating-point tolerance)
- Checks: All force components (x, y, z) for all atoms
- Method: Absolute difference comparison

---

## Physical Background

### Lennard-Jones Potential

The Lennard-Jones (LJ) potential models van der Waals interactions:

```
U(r) = 4ε[(σ/r)¹² - (σ/r)⁶]
```

Where:
- **r**: Distance between atoms
- **ε**: Depth of potential well (energy scale)
- **σ**: Finite distance at which potential is zero (length scale)

**Force Calculation:**

```
F(r) = -dU/dr = 24ε/r × [2(σ/r)¹² - (σ/r)⁶]
```

**Parameters in this benchmark:**
- `lj1 = 4ε·σ¹² = 1.5` (repulsive term)
- `lj2 = 4ε·σ⁶ = 2.0` (attractive term)
- Van der Waals radius: σ ≈ 1.049

**Physical Interpretation:**
- **r < σ**: Strong repulsion (atoms too close)
- **r ≈ σ**: Equilibrium (minimum energy)
- **r > σ**: Weak attraction (van der Waals)
- **r >> σ**: Negligible interaction (cutoff)

---

## Grid-Based Optimization

### Why Use a Grid?

**Problem**: Naive N-body force calculation requires checking all pairs:
- Time complexity: O(n²)
- For 256 atoms: 32,640 pairwise comparisons

**Solution**: Spatial partitioning with grid structure:
1. **Divide**: Split domain into 4×4×4 = 64 cells
2. **Assign**: Place each atom in its corresponding cell
3. **Local Search**: Only check atoms in neighboring cells

**Benefits:**
- Reduces search space from O(n) to O(local_atoms)
- Typical cell: 3-5 atoms (256/64 ≈ 4 average)
- Neighbor cells: 27 (including self)
- Effective neighbors: ~100 comparisons per atom vs. 255

**Trade-offs:**
- Memory overhead: Grid data structure
- Binning cost: O(n) to assign atoms to cells
- Load imbalance: Cells may have varying populations

---

## Dataset Characteristics

### Spatial Distribution

Each dataset has a unique atom distribution due to different random seeds:

**Generation Process:**
1. Randomly generate 3D positions in [0, 20.0]³
2. Reject positions violating van der Waals threshold (prevents overlap)
3. Accept when 256 valid atoms are generated
4. Bin atoms into 4×4×4 grid structure

**Properties:**
- **Uniform Density**: Average ~4 atoms per cell (256/64)
- **Random Clustering**: Some cells have more/fewer atoms
- **Physical Validity**: All atoms respect minimum distance constraint
- **Boundary Handling**: Atoms near edges interact with fewer neighbors

### Why Different Seeds Matter

Different random seeds produce:
- **Varied Clustering**: Different local densities in grid cells
- **Edge Cases**: Atoms near boundaries vs. interior
- **Load Imbalance**: Cells with 0-10 atoms
- **Force Magnitudes**: Varies with local configuration

This diversity ensures the algorithm is tested across realistic molecular configurations.

---

## Usage

### Test Single Dataset:

```bash
./EX1_optimized_codes/md_gcc \
    input_data/mini/input/input.data \
    input_data/mini/output/check.data
```

**Expected output:**
```
Success.
```

### Test All Datasets:

```bash
for size in mini small medium large extra-large; do
    echo "Testing $size..."
    ./EX1_optimized_codes/md_gcc \
        input_data/$size/input/input.data \
        input_data/$size/output/check.data
done
```

### Regenerate All Data:

```bash
# From md-grid-mach directory
bash generate_all_data.sh
```

---

## Performance Considerations

### Computational Characteristics

**Dominant Operations:**
- Distance calculations: `sqrt((x1-x2)² + (y1-y2)² + (z1-z2)²)`
- Force evaluation: Lennard-Jones potential (exponentials)
- Accumulation: Vector addition

**Memory Access Pattern:**
- Streaming: Read atom positions from grid cells
- Random access: Force accumulation to result array
- Cache-friendly: Grid structure promotes spatial locality

**Optimization Opportunities:**
- Loop unrolling in force calculations
- SIMD vectorization of distance/force computations
- Cache blocking for better data reuse
- Symmetry exploitation: F_ij = -F_ji

### Expected Runtime (O3 optimization):
- Mini/Small/Medium/Large/Extra-large: ~1-5 ms (all same size)
- Variation: ±20% due to different spatial distributions

---

## Physical Significance

### Applications of MD Simulations

Molecular dynamics with Lennard-Jones potentials is used in:

1. **Materials Science**
   - Liquid argon behavior
   - Noble gas properties
   - Phase transitions

2. **Chemistry**
   - Protein folding (simplified models)
   - Drug-molecule interactions
   - Solvation dynamics

3. **Physics**
   - Statistical mechanics validation
   - Thermodynamic property calculation
   - Transport phenomena

### Limitations of This Benchmark

- **Simplified Potential**: Real molecules use more complex potentials
- **Fixed Domain**: No periodic boundary conditions
- **Small System**: 256 atoms (production runs use millions)
- **Single Step**: Real MD requires time integration over many steps

---

## References

### Molecular Dynamics Background

- **Lennard-Jones Potential**: J. E. Jones, Proc. Royal Soc. A (1924)
- **MD Method**: B. J. Alder & T. E. Wainwright, J. Chem. Phys. (1957)
- **Grid-Based Optimization**: Verlet Neighbor Lists (1967)

### Related Benchmarks

- **md-knn-mach**: KNN-based neighbor search (different partitioning)
- **nw-mach**: Needleman-Wunsch (different application domain)

---

## Troubleshooting

### Common Issues

**Issue**: "Invalid input: line X of section Y"
- **Cause**: Corrupted input data file
- **Fix**: Regenerate using `bash generate_all_data.sh`

**Issue**: "Benchmark results are incorrect"
- **Cause**: check.data doesn't match computed forces
- **Fix**: Regenerate check.data using baseline program

**Issue**: All forces are zero
- **Cause**: Atoms too far apart (beyond cutoff)
- **Fix**: Normal for some configurations; check if seed is valid

---

## Dataset Metadata

| Property | Value |
|----------|-------|
| Benchmark Name | md-grid-mach |
| Algorithm | Molecular Dynamics (Lennard-Jones) |
| Optimization | Grid-based spatial partitioning |
| Input Size | Fixed (256 atoms, 4×4×4 grid) |
| Dataset Count | 5 |
| Total Data Size | ~360 KB (10 files) |
| Validation Method | Floating-point comparison (ε=1e-6) |
| Generation Time | ~1 second (all datasets) |
| Verification Time | ~5 ms per dataset |

---

## Summary

The **MD-Grid-Mach** dataset provides 5 test cases with different random atom distributions for validating molecular dynamics implementations. All datasets maintain the same size (256 atoms) but vary in spatial configuration, ensuring comprehensive testing of the grid-based force calculation algorithm across diverse molecular scenarios.

**Key Takeaways:**
- ✅ Fixed scale: All datasets use 256 atoms in 4×4×4 grid
- ✅ Different patterns: 5 random spatial distributions
- ✅ Physically valid: All atoms respect minimum distance constraints
- ✅ Algorithm test: Grid-based N-body force calculation
- ✅ Optimization target: Spatial partitioning for reduced complexity

For questions or issues, refer to the MachSuite documentation or regenerate data using the provided script.

